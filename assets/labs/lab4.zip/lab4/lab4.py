# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "marimo>=0.23.3",
#     "anthropic",
#     "numpy",
#     "pandas",
#     "matplotlib",
#     "scikit-learn",
#     "torch",
#     "transformers",
# ]
# ///

import marimo

__generated_with = "0.23.16"
app = marimo.App(width="medium")

with app.setup:
    import marimo as mo

    import difflib
    import html
    import json
    import math
    import os
    import random
    import re
    import time
    import urllib.error
    import urllib.request
    from datetime import datetime, timezone

    import numpy as np
    import pandas as pd

    LABELS = ("biased", "neutral")


@app.cell
def _():
    # Fill in your information, as in Labs 1 and 3.
    NAME = ""
    ANDREW_ID = ""
    GROUP = ""
    ASSIGNMENT = "Lab 4: Model Adaptation and Inference"
    DATE = ""

    _missing = [
        _key for _key, _value in
        [("NAME", NAME), ("ANDREW_ID", ANDREW_ID), ("GROUP", GROUP), ("DATE", DATE)]
        if not _value.strip()
    ]
    _header = mo.md(
        f"# {ASSIGNMENT}\n\n**Name:** {NAME or '(name)'}\n\n"
        f"**Andrew ID:** {ANDREW_ID or '(andrewID)'}\n\n"
        f"**Group:** {GROUP or '(group name / members)'}\n\n"
        f"**Date:** {DATE or '(date)'}"
    )
    mo.vstack([
        _header,
        *([mo.callout(mo.md(
            f"Header incomplete. Fill in: {', '.join(_missing)}"
        ), kind="info")] if _missing else []),
    ])
    return


@app.cell
def _():
    QUESTIONS = {
        1: "[INDIVIDUAL] Warm-up: what does a neutralizing edit look like?",
        2: "[INDIVIDUAL] One-token classification on a fixed budget",
        3: "[INDIVIDUAL] A workload whose lengths you have to look up",
        4: "[INDIVIDUAL] Training memory for `qwen3-8b-wnc`",
        5: "[INDIVIDUAL] Which model, and what does it take to make it work?",
        6: "[INDIVIDUAL] Better and worse training settings",
        7: "[INDIVIDUAL] Generate and evaluate neutral rewrites",
        8: "[GROUP] Identify tasks",
        9: "[GROUP] Choose an approach",
        10: "[INDIVIDUAL] One step further",
    }
    PLACEHOLDER = "(write your answer here)"
    return PLACEHOLDER, QUESTIONS


@app.cell
def _(
    answer_1,
    answer_10,
    answer_2,
    answer_3,
    answer_4,
    answer_5,
    answer_6,
    answer_7,
    answer_8,
    answer_9,
):
    # Explicit dependencies make marimo rebuild the summary after answer edits.
    ANSWERS = {
        1: answer_1, 2: answer_2, 3: answer_3, 4: answer_4,
        5: answer_5, 6: answer_6, 7: answer_7,
        8: answer_8, 9: answer_9, 10: answer_10,
    }
    return (ANSWERS,)


@app.cell(hide_code=True)
def _(ANSWERS, PLACEHOLDER, QUESTIONS):
    _rows, _done = [], 0
    for _number, _title in QUESTIONS.items():
        _answer = (ANSWERS.get(_number) or "").strip()
        _complete = bool(_answer) and _answer != PLACEHOLDER.strip()
        _done += _complete
        _mark = "✅" if _complete else "⬜"
        _rows.append(
            f"**{_mark} Question {_number}: {_title}**\n\n"
            + (_answer if _complete else "_not yet answered_")
        )
    mo.vstack([
        mo.md(f"## Answer sheet: {_done}/{len(QUESTIONS)} written"),
        mo.callout(mo.md(
            "Fill in each `answer_N` cell immediately below its question, then "
            "run that cell. Your responses appear here automatically. "
            "A check mark means text is present; it does not assess the answer."
        ), kind="info"),
        mo.md("\n\n---\n\n".join(_rows)),
    ])
    return


@app.function
def word_diff_html(before: str, after: str) -> str:
    """Word-level diff: removed words struck through in red, added words bold in green.
    Matching ignores capitalization (WNC sentences are lowercase; many LLMs capitalize their rewrites)."""
    a, b = before.split(), after.split()
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=[w.lower() for w in a], b=[w.lower() for w in b],
                                                      autojunk=False).get_opcodes():
        if op == "equal":
            out.append(html.escape(" ".join(a[i1:i2])))
            continue
        if i2 > i1:
            out.append(f"<del style='color:#b42318'>{html.escape(' '.join(a[i1:i2]))}</del>")
        if j2 > j1:
            out.append(f"<ins style='color:#067647;font-weight:600;text-decoration:none'>{html.escape(' '.join(b[j1:j2]))}</ins>")
    return " ".join(out)


@app.function
def parse_label(raw) -> str | None:
    """Map a model's raw output to 'biased' / 'neutral', or None if it is not a valid label.

    Policy (strict): lowercase, strip whitespace/punctuation/quotes, then accept
    an output whose first word is a label, unless the other label also appears (a hedge such as
    "biased/neutral"). Anything else is invalid and is scored as wrong (never silently dropped).
    """
    if raw is None:
        return None
    words = re.sub(r"[^a-z\s]", " ", str(raw).lower()).split()
    if not words or words[0] not in LABELS:
        return None
    return None if set(LABELS) <= set(words) else words[0]


@app.function
def wilson_ci(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """95% Wilson interval for a proportion k/n (uncertainty across evaluation items only)."""
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (centre - half, centre + half)


@app.function
def score_predictions(preds: pd.DataFrame, gold: pd.DataFrame) -> dict:
    """Score one run against gold labels on exactly the gold IDs.

    preds: columns sentence_id, parsed_label (None/NaN = invalid output).
    gold:  columns sentence_id, pair_id, label.
    Missing predictions and invalid outputs both count as wrong and are reported separately.
    """
    merged = gold[["sentence_id", "pair_id", "label"]].merge(
        preds[["sentence_id", "parsed_label"]], on="sentence_id", how="left")
    n = len(merged)
    missing = int((~merged["sentence_id"].isin(preds["sentence_id"])).sum())
    invalid = int(merged["parsed_label"].isna().sum()) - missing
    correct = merged["parsed_label"] == merged["label"]
    k = int(correct.sum())
    pair_ok = correct.groupby(merged["pair_id"]).all()
    lo, hi = wilson_ci(k, n)
    plo, phi = wilson_ci(int(pair_ok.sum()), len(pair_ok))
    valid = merged["parsed_label"].notna()
    return {
        "n_sentences": n,
        "missing": missing,
        "invalid": invalid,
        "accuracy": k / n if n else float("nan"),
        "acc_95ci": f"[{lo:.3f}, {hi:.3f}]",
        "pairs_both_correct": pair_ok.mean() if len(pair_ok) else float("nan"),
        "pairs_95ci": f"[{plo:.3f}, {phi:.3f}]",
        "pred_biased_rate": (merged.loc[valid, "parsed_label"] == "biased").mean() if valid.any() else float("nan"),
    }


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## Objectives

    - Understand when and how to pick hardware, models, adaptation, and inference strategies to align with your use case.
    - Practice using AI language models for inference and evaluating their outputs.

    We will work through a shared task, then use what we learn to identify "tasks" and plan approaches for your project. Along the way, you will estimate hardware and context requirements, compare in-context learning with training, and train a small model, analyzing its settings and hyperparameters.

    ## Working in this notebook

    Each question's heading starts with "Question N", and each question has an `answer_N` cell directly below it. Replace the placeholder with your response; bullets and working notes are welcome. The answer sheet above collects your responses.

    You may talk through any part of this lab with your project group, but each of you submits your own notebook with your own answers. Each question is marked:

    - `[INDIVIDUAL]`: write your own answer.
    - `[GROUP]`: your group may submit the same answer.

    ## Due date and submission

    Due **Friday, November 20, 11:59 pm**. Submit on Canvas:

    - this notebook, with your information and answers filled in;
    - a zip of your `lab4_runs` folder, which holds the records of your model runs. (Trained model weights are saved separately in `lab4_ckpts`; don't submit that folder.)

    -----

    #### Allowed and recommended resources

    - assistance from course staff
    - provided scaffolding in released materials for homework
    - official documentation such as through `help()` and [dataset cards](https://huggingface.co/docs/hub/datasets-cards)
    - piazza Q&A (your own questions and/or others')
    - other course materials (e.g. released in-class activities)
    - internet for general resources to understand subject material, including looking up GPU and API prices
    - speech-to-text to help transcribe answers
    - running language models through the notebook wherever a question asks you to (Questions 5, 7 and 10)
    - AI assistance with setup and debugging only (installing packages, configuring your `.env`, fixing errors), not for writing or computing your answers
    - sharing compute access with classmates (or asking instructors for assistance)
    - sharing `[GROUP]` answers verbatim with group members

    #### Prohibited

    - AI-generated answers to assignment questions, including the calculations in Questions 2 to 5
    - copying a friend's notebook for individual answers

    #### Explicitly not required

    - polished prose (complete sentences, grammar): for this assignment, we will evaluate written answers for thoughtful responses, which should be expressed clearly and precisely enough to be legible to your peers and instructors, but need not be in complete sentences of Standard English for full credit. e.g. if you would sometimes tend to use a dedicated grammar checker (or LLM) on your writing before submission, we would happily accept, and would actually prefer, the more "raw" version
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    # Part I: Exploring a shared task

    We will use Wikipedia Neutrality Corpus (WNC; [Pryzant et al., 2020](https://arxiv.org/abs/1911.09709)) sentence pairs for two tasks: 1) classification of a sentence as biased or neutral, and 2) "neutralizing" a biased sentence via rewrite to align with Wikipedia's Neutral Point of View ([NPOV](https://en.wikipedia.org/wiki/Wikipedia:Neutral_point_of_view)) policy. The corpus includes pairs of passages pre- and post-edit, and the original work by Pryzant et al. propose two algorithms which each use [BERT](https://arxiv.org/abs/1810.04805) (a *masked* language model with only an encoder, which does not naturally "generate" language the way many recent models do) along with an attentional LSTM to detect and neutralize bias. Recent work has established that LLM-generated rewrites of biased passages are often preferred over the original by human crowdworker annotators, but that they struggle with bias *detection* and tend to propose more heavy-handed changes than human editors ([Ashkinaze et al., 2026](https://arxiv.org/abs/2407.04183)).


    ## Task setup
    - The prepared data is in `data/wnc/`. If you want to see how we built it from the original corpus, read `data/wnc/README.md` or rerun `python data/wnc/prepare_wnc.py` (optional).
    - Read Wikipedia's NPOV policy [here](https://en.wikipedia.org/wiki/Wikipedia:Neutral_point_of_view)
    - Skim sections 1–3 of Pryzant et al.'s paper ([Pryzant et al., 2020](https://arxiv.org/abs/1911.09709)) to understand their problem formulation

    **Start this first.** Question 6 needs several bert-mini training runs: about 30 minutes in total on a laptop CPU, or a few minutes on a recent Mac or a machine with a CUDA GPU. Before you begin Question 1, open a terminal in the Lab 4 folder and run

    ```
    python train_bert.py --seeds 0 1 2
    ```

    to train the default setting three times (the first three of the runs Question 6 needs). It runs in the background while you work on Questions 1–5, and the results will be waiting when you reach Question 6. Don't start the same setting from the notebook while this is still running, since both would write to the same folder.
    """)
    return


@app.cell
def _():
    # Where the prepared WNC files live. Change this only if you moved the folder.
    WNC_DIR = mo.notebook_dir() / "data" / "wnc"

    _needed = ["pairs.csv.gz", "sentences.csv.gz", "eval_subset.csv", "manifest.json"]
    _missing = [_f for _f in _needed if not (WNC_DIR / _f).exists()]
    mo.stop(
        bool(_missing),
        mo.callout(mo.md(
            f"Missing WNC files in `{WNC_DIR}`: {', '.join(_missing)}.\n\n"
            "Run `python data/wnc/prepare_wnc.py` from the Lab 4 folder (see `data/wnc/README.md`), then rerun this cell."
        ), kind="danger"),
    )
    _read = dict(keep_default_na=False, dtype={"rev_id": str})
    pairs = pd.read_csv(WNC_DIR / "pairs.csv.gz", **_read)
    sentences = pd.read_csv(WNC_DIR / "sentences.csv.gz", keep_default_na=False)
    EVAL_SET = pd.read_csv(WNC_DIR / "eval_subset.csv", keep_default_na=False)
    wnc_manifest = json.loads((WNC_DIR / "manifest.json").read_text())
    return EVAL_SET, pairs, sentences, wnc_manifest


@app.cell(hide_code=True)
def _(EVAL_SET, pairs, sentences, wnc_manifest):
    # Readiness report: do the loaded files match the release manifest?
    _counts = (
        sentences.groupby(["split", "label"]).size().unstack(fill_value=0)
        .reindex(["train", "dev", "test"])
    )
    _counts["pairs"] = pairs.groupby("split").size()
    _counts["label-conflict pairs"] = pairs.groupby("split")["label_conflict"].sum()
    _expected = {s: c["released_pairs"] for s, c in wnc_manifest["counts"].items()}
    _ok = all(int(_counts.loc[s, "pairs"]) == n for s, n in _expected.items()) and len(EVAL_SET) == wnc_manifest["eval_subset"]["sentences"]
    mo.vstack([
        mo.md("### WNC data: split and label counts"),
        mo.ui.table(_counts.reset_index(), selection=None, show_column_summaries=False),
        mo.callout(
            mo.md(f"Data loaded and matches the release manifest. Fixed evaluation subset: **{len(EVAL_SET)} sentences** "
                  f"({EVAL_SET['pair_id'].nunique()} test pairs)." if _ok else
                  "Loaded counts do **not** match `manifest.json`. Rebuild with `prepare_wnc.py` before continuing."),
            kind="success" if _ok else "danger",
        ),
    ])
    return


@app.cell
def _(EVAL_SET, pairs):
    # Data pools used throughout Part I. Keep test data out of training and demonstrations.
    TRAIN_PAIRS = pairs[pairs["split"] == "train"].reset_index(drop=True)
    DEMO_POOL = pairs[pairs["split"] == "dev"].reset_index(drop=True)  # in-context demonstrations come only from here

    _eval_texts = set(EVAL_SET["text"])
    for _name, _pool in [("train", TRAIN_PAIRS), ("demo", DEMO_POOL)]:
        assert not (_eval_texts & (set(_pool["biased_text"]) | set(_pool["neutral_text"]))), f"{_name} pool overlaps EVAL_SET"
    return DEMO_POOL, TRAIN_PAIRS


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## Four edits from the corpus

    Each row is one edit from the training split. <del style="color:#b42318">Struck-through red</del> words were removed by the editor and <b style="color:#067647">green</b> words were added. The corpus labels the sentence before the edit `biased` and the sentence after it `neutral`.
    """)
    return


@app.cell(hide_code=True)
def _(pairs):
    Q1_PAIR_IDS = ["train-46964", "train-30625", "train-16913", "train-35800"]
    _shown = pairs.set_index("pair_id").loc[Q1_PAIR_IDS]
    _rows = "".join(
        f"<tr><td style='white-space:nowrap;vertical-align:top'><code>{_pid}</code></td>"
        f"<td style='vertical-align:top'>{word_diff_html(_r.biased_text, _r.neutral_text)}</td></tr>"
        for _pid, _r in _shown.iterrows()
    )
    mo.Html(f"<table><thead><tr><th>pair_id</th><th>edit (before → after)</th></tr></thead><tbody>{_rows}</tbody></table>")
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 1: Warm-up: what does a neutralizing edit look like? `[INDIVIDUAL]`

    a) For each of the four edits above, say in a few words why the original might violate NPOV and what the editor changed. Do you agree with every edit?

    b) Pryzant et al. evaluate their systems by comparing generated rewrites against the editor's version (BLEU and exact-match accuracy) and with a small human study. Name one limitation of evaluating "neutralization" this way. Keep in mind that each sentence has exactly one reference rewrite.
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # a) one line per edit (refer to them by pair_id); b) one limitation, explained in a sentence or two.
    answer_1 = PLACEHOLDER
    mo.md(answer_1)
    return (answer_1,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    # Planning GPU memory for inference and training

    How much GPU memory should you set aside, and what workload will that support? We start with inference, then look at what changes during training. Show your calculations with units. These are planning exercises: you won't run these models.
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    **The KV cache.** A language model first reads the prompt (*prefill*), then generates new tokens one at a time (*decode*). To avoid recomputing attention over earlier tokens at every step, it keeps their key and value vectors in a **KV cache**. This takes GPU memory alongside the model weights, and it grows with the number of tokens in every active request.

    **Reserving cache space.** Serving systems like vLLM set aside a pool of cache memory and hand out pieces to requests as they grow. They also manage the queue for you: a fixed number of requests run on the GPU at once, and the next one starts as soon as one finishes. Reserve too little and requests wait, get rejected, or are paused and recomputed (slower). Reserve too much and you leave less room for other work. [How caching works](https://huggingface.co/docs/transformers/main/en/cache_explanation) · [vLLM memory settings](https://docs.vllm.ai/en/latest/configuration/optimization/)
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## A first cache calculation

    For one sequence on one GPU, the KV cache takes about

    \[
    M_{\mathrm{KV}} = 2 \cdot L \cdot H_{\mathrm{KV}} \cdot d_h \cdot b \cdot T \quad \text{bytes},
    \]

    where 2 counts keys and values, \(L\) is the number of layers, \(H_{\mathrm{KV}}\) the number of key-value heads, \(d_h\) the size of each head, \(b\) the bytes per number (2 for a 16-bit cache), and \(T\) the number of tokens kept (prompt plus output). For several active requests, add up their \(T\). Servers like vLLM hand out cache memory in fixed-size blocks, so round each request's tokens up to a whole number of blocks.

    Some models share key-value heads across several query heads (grouped-query attention). Use the number of **key-value** heads in the formula, not the number of query heads.

    **Example model:** [OPT-6.7B](https://huggingface.co/facebook/opt-6.7b/raw/main/config.json) has 32 layers, 32 heads (all used for keys and values), and hidden size 4,096, so \(d_h=128\). Its context limit is 2,048 tokens.

    Then check that everything fits, using \(1\,\mathrm{GiB}=2^{30}\) bytes:

    \[
    M_{\mathrm{weights}} + M_{\mathrm{KV}} + M_{\mathrm{other}} + M_{\mathrm{headroom}} \leq M_{\mathrm{GPU}}.
    \]

    Fitting in memory doesn't guarantee good speed; it only means the server can run.
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 2: One-token classification on a fixed budget `[INDIVIDUAL]`

    You need to classify a large queue of multiple-choice items with **OPT-6.7B**. Each request contains the question and its choices, and the model answers with exactly one token. The server reserves cache space for **2,048 tokens per active request** (prompt plus the one answer token). The GPU has **24 GiB** of usable memory; the weights take **13 GiB**, and other working memory takes about **3 GiB**. These are given numbers for the exercise, not measurements. For this model, each token takes **0.5 MiB** of KV cache.

    1. How much KV-cache memory does one active request need? How many requests could run at once if memory were the only limit, and how many would you actually allow, leaving some headroom (for example, 1–2 GiB)?
    2. You want to add worked examples to the prompt. If the instructions and question take 400 tokens and each worked example takes 150, how many examples fit?

    *Note:* when you only need the model's first output token, there are no later decoding steps, so the KV cache isn't needed once the prompt has been read. The model still runs every prompt token through every layer, so that computation and its temporary memory remain.
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # 1) KV memory per request, memory-only maximum, and the number you'd allow; 2) how many examples fit, with the arithmetic.
    answer_2 = PLACEHOLDER
    mo.md(answer_2)
    return (answer_2,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 3: A workload whose lengths you have to look up `[INDIVIDUAL]`

    Now plan a summarization service with **Qwen3-8B**, the same model behind `qwen3-8b-wnc`, on one **NVIDIA L40S** with about **44.4 GiB** of usable memory. The weights take about **15.3 GiB** and other working memory about **3 GiB**. The cache stores 16-bit numbers (2 bytes each) in blocks of 16 tokens. From the [model configuration](https://huggingface.co/Qwen/Qwen3-8B/raw/main/config.json): 36 layers, **8 key-value heads**, and each head's key and value vectors have 128 numbers (\(d_h = 128\)). The model's context limit is 32,768 tokens.

    1. Look up typical document and summary lengths for [CNN/DailyMail](https://huggingface.co/datasets/abisee/cnn_dailymail) and the [arXiv summarization dataset](https://github.com/armancohan/long-summarization). Dataset cards or papers are fine; say where your numbers come from and whether they are words or tokens. If you only find word counts, assume roughly 1.3 tokens per English word.
    2. Pick one dataset. Choose a maximum input length and a maximum output length, and say what you would do with documents that are longer than your limit.
    3. How much KV-cache memory does one request need at your limits, including block rounding? How many requests can run at once, leaving some headroom?
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # 1) lengths with sources and units; 2) your input/output limits and long-document policy; 3) KV per request with block rounding, and how many fit.
    answer_3 = PLACEHOLDER
    mo.md(answer_3)
    return (answer_3,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## What changes when we train?

    In training, the model reads the whole target text at once, so there's no KV cache carried between steps. Instead, memory goes to the weights, a gradient for every parameter being trained, the optimizer's running statistics, and the intermediate values (*activations*) saved for computing gradients. A common rule of thumb for full fine-tuning (mixed precision, AdamW optimizer) is **16 bytes per trained parameter** before activations: 2 for the weight, 2 for its gradient, 4 for a full-precision copy and 8 for the optimizer's statistics. With **LoRA**, only the small adapter matrices are trained, so only they need gradients and optimizer state. The frozen base weights still take 2 bytes per parameter.

    Activation memory grows with the number of sentences processed at once. **Gradient accumulation** lets you train with a large batch without holding it all in memory: split the batch into smaller *micro-batches*, run each one forward and backward, add up their gradients, and update the weights only after the last one. The update is the same as with the full batch, but only one micro-batch's activations are in memory at a time. The cost is time, since the micro-batches run one after another.

    **Online reinforcement learning** (for example GRPO) alternates three phases: the current model generates answers (which uses a KV cache, like inference), the answers are scored, and the model is updated (which needs training memory). Peak memory depends on which of these are on the GPU at the same time, and run time depends on how long the generated answers are, which varies.
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 4: Training memory for `qwen3-8b-wnc` `[INDIVIDUAL]`

    1. Qwen3-8B has 8.2 billion parameters, so by the rule of thumb *full* fine-tuning would need about 122 GiB before activations, far more than one L40S (44.4 GiB usable). Our LoRA adapter trains 15.3 million parameters with the base frozen. How much memory does that need before activations?
    2. Training `qwen3-8b-wnc` with all 16 sentences of a batch at once peaked at about 63 GiB, so it didn't fit on one L40S. Suppose we use gradient accumulation with micro-batches of 4 sentences instead. Assume activation memory is proportional to the number of sentences in a micro-batch, and that everything else is the LoRA memory from part 1. Estimate the new peak. Does it fit? How many micro-batches make up each update?
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # 1) LoRA memory before activations, and whether it fits; 2) estimated peak with micro-batches of 4, whether it fits, micro-batches per update.
    answer_4 = PLACEHOLDER
    mo.md(answer_4)
    return (answer_4,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    # Training or prompting?

    There are two broad ways to adapt a language model to a task like this one: **train** it on labeled examples, or keep it frozen and **prompt** it with instructions and examples (in-context learning). Here you compare both on the same 400 evaluation sentences. Every run is saved to `lab4_runs/` and appears in the results table below.
    """)
    return


@app.function
def run_classifier(name: str, model: str, adaptation: str, settings: dict, predict_fn, items: pd.DataFrame,
                   max_consecutive_errors: int = 5, workers: int = 1) -> dict:
    """Run predict_fn on every item and return a run record (nothing is sent anywhere else).

    items: DataFrame with sentence_id, text.
    predict_fn(text) -> str, or dict with raw_output and optionally input_tokens / output_tokens.
    workers > 1 sends that many requests at a time. Stops early after `max_consecutive_errors` failures in a
    row (e.g. a bad API key); items not reached are recorded as missing, so a partial run never looks complete.
    """
    from concurrent.futures import ThreadPoolExecutor

    def one(r):
        t0, err, out = time.perf_counter(), None, {}
        try:
            res = predict_fn(r.text)
            out = res if isinstance(res, dict) else {"raw_output": res}
        except Exception as e:  # recorded, not hidden
            err = f"{type(e).__name__}: {e}"
        return {
            "sentence_id": r.sentence_id,
            "raw_output": out.get("raw_output"),
            "parsed_label": parse_label(out.get("raw_output")),
            "error": err,
            "latency_s": round(time.perf_counter() - t0, 4),
            "input_tokens": out.get("input_tokens"),
            "output_tokens": out.get("output_tokens"),
        }

    rows, streak, t_start = [], 0, time.perf_counter()
    todo = list(items.itertuples())
    with ThreadPoolExecutor(max(1, workers)) as pool:
        for i in range(0, len(todo), max(1, workers)):
            if streak >= max_consecutive_errors:
                break
            for row in pool.map(one, todo[i:i + max(1, workers)]):
                rows.append(row)
                streak = streak + 1 if row["error"] else 0
    now = datetime.now(timezone.utc)
    return {
        "run_id": f"{now:%Y%m%dT%H%M%SZ}-{re.sub(r'[^A-Za-z0-9_-]+', '-', name)}",
        "kind": "classify",
        "name": name,
        "created_utc": now.isoformat(timespec="seconds"),
        "model": model,
        "adaptation": adaptation,
        "settings": settings,
        "n_items": len(items),
        "n_attempted": len(rows),
        "stopped_early": len(rows) < len(items),
        "wall_time_s": round(time.perf_counter() - t_start, 2),
        "predictions": rows,
    }


@app.function
def save_run(record: dict, runs_dir) -> str:
    runs_dir.mkdir(parents=True, exist_ok=True)
    path = runs_dir / f"{record['run_id']}.json"
    path.write_text(json.dumps(record, indent=1))
    return str(path)


@app.function
def load_runs(runs_dir) -> list[dict]:
    if not runs_dir.exists():
        return []
    return [json.loads(p.read_text()) for p in sorted(runs_dir.glob("*.json"))]


@app.function
def select_demos(pool: pd.DataFrame, k: int, seed: int) -> pd.DataFrame:
    """k demonstrations from k distinct pairs in `pool` (the dev split), alternating labels, in shuffled order.

    One sentence per pair, so no demonstration pair gives away its own contrast.
    """
    rng = random.Random(seed)
    chosen = pool.sample(n=k, random_state=seed) if k else pool.iloc[:0]
    demos = [
        {"pair_id": r.pair_id, "text": r.biased_text if i % 2 == 0 else r.neutral_text,
         "label": "biased" if i % 2 == 0 else "neutral"}
        for i, r in enumerate(chosen.itertuples())
    ]
    rng.shuffle(demos)
    return pd.DataFrame(demos, columns=["pair_id", "text", "label"])


@app.function
def format_prompt(template: str, text: str, demos: pd.DataFrame) -> str:
    block = "".join(f"Sentence: {d.text}\nLabel: {d.label}\n\n" for d in demos.itertuples())
    return template.format(demonstrations=block, text=text)


@app.function
def course_url_default() -> str:
    """Where the course model is served (Modal)."""
    return "https://csna--lab4-vllm-l40s-server.us-east.modal.direct/v1"


@app.function
def load_env_file(path) -> None:
    """Read KEY=value lines from a .env file into the environment (existing variables win). Values are never shown."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip().removeprefix("export ").strip(), v.strip().strip('"').strip("'"))


@app.function
def endpoint_config(endpoint: str) -> dict:
    """Settings for one endpoint, read from the environment (or a .env file) so keys are never saved in the notebook.

    endpoint="course": the course server (Qwen3-8B, untuned and fine-tuned; thinking off)
        LAB4_COURSE_API_KEY (the shared course key from Piazza); the URL is course_url_default() unless LAB4_COURSE_BASE_URL is set
    endpoint="llm": Claude models through Anthropic's API
        ANTHROPIC_API_KEY
    """
    keys = {"course": ("LAB4_COURSE_API_KEY",), "llm": ("ANTHROPIC_API_KEY",)}[endpoint]
    cfg = {k: os.environ.get(k, "").strip() for k in keys}
    cfg["missing"] = [k for k in keys if not cfg[k]]
    return cfg


@app.function
def claude_cost(model: str, input_tokens, output_tokens):
    """Estimated $ cost of a Claude run from its token counts (published prices, Nov 2026); None for other models."""
    prices = {"claude-haiku-5-5": (0.10, 0.50), "claude-opus-5-5": (4.00, 20.00)}
    key = str(model).split(":")[-1]
    if key not in prices:
        return None
    pin, pout = prices[key]
    return round((pd.to_numeric(input_tokens).sum() * pin + pd.to_numeric(output_tokens).sum() * pout) / 1e6, 3)


@app.function
def claude_request_kwargs(model: str, effort: str = "low", json_label: bool = False, max_output_tokens: int = 64) -> dict:
    """Request settings for a Claude call. effort "low" = minimal thinking (off on Haiku; Opus can't turn it
    off, so it runs at low effort). Higher efforts: adaptive thinking at that effort. json_label: constrain the
    answer to {"label": "biased" | "neutral"}."""
    oc = {}
    if json_label:
        oc["format"] = {"type": "json_schema", "schema": {
            "type": "object", "properties": {"label": {"type": "string", "enum": ["biased", "neutral"]}},
            "required": ["label"], "additionalProperties": False}}
    if effort == "low" and model.startswith("claude-haiku"):
        kw = {"max_tokens": max_output_tokens, "thinking": {"type": "disabled"}}
    else:
        kw = {"max_tokens": max(8192, max_output_tokens)}
        oc["effort"] = effort
    if oc:
        kw["output_config"] = oc
    return kw


@app.function
def call_model(prompt: str, settings: dict, endpoint: str = "llm", model: str | None = None,
               timeout_s: float = 60.0, wake_wait_s: float = 240.0) -> dict:
    """Send one prompt and return {"raw_output", "input_tokens", "output_tokens", "finish_reason"}.

    endpoint="course": model "qwen3-8b" or "qwen3-8b-wnc" on the course server (OpenAI-compatible; retries while it wakes up).
    endpoint="llm": a Claude model, e.g. "claude-haiku-5-5"; settings may set effort, json_label, max_output_tokens.
    """
    cfg = endpoint_config(endpoint)
    if cfg["missing"]:
        raise RuntimeError("endpoint not configured; set " + ", ".join(cfg["missing"]) + " in your .env file")
    if endpoint == "llm":
        import anthropic
        client = anthropic.Anthropic(api_key=cfg["ANTHROPIC_API_KEY"], timeout=timeout_s, max_retries=4)
        kw = claude_request_kwargs(model, settings.get("effort", "low"), settings.get("json_label", False),
                                   settings.get("max_output_tokens", 64))
        r = client.messages.create(model=model, messages=[{"role": "user", "content": prompt}], **kw)
        text = "".join(b.text for b in r.content if b.type == "text").strip()
        if settings.get("json_label") and text:
            try:
                text = json.loads(text)["label"]
            except Exception:
                pass
        return {"raw_output": text, "input_tokens": r.usage.input_tokens, "output_tokens": r.usage.output_tokens,
                "finish_reason": r.stop_reason}
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": settings.get("temperature", 0),
        "max_tokens": settings.get("max_output_tokens", 64),
        # Qwen3 writes a reasoning trace unless thinking is switched off; the WNC adapter was trained this way.
        "chat_template_kwargs": {"enable_thinking": False},
    }).encode()
    url = (os.environ.get("LAB4_COURSE_BASE_URL") or course_url_default()).rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {cfg['LAB4_COURSE_API_KEY']}"}
    deadline, wait = time.time() + wake_wait_s, 5.0
    while True:
        try:
            with urllib.request.urlopen(urllib.request.Request(url, data=body, method="POST", headers=headers),
                                        timeout=timeout_s) as resp:
                data = json.loads(resp.read())
            break
        except urllib.error.HTTPError as e:
            if e.code in (429, 502, 503, 504) and time.time() < deadline:  # waking up or rate-limited
                time.sleep(wait)
                wait = min(wait * 1.5, 30.0)
                continue
            raise RuntimeError(f"HTTP {e.code}: {e.read(500).decode(errors='replace')}") from None
    choice = data["choices"][0]
    usage = data.get("usage") or {}
    return {
        "raw_output": (choice.get("message") or {}).get("content"),
        "input_tokens": usage.get("prompt_tokens"),
        "output_tokens": usage.get("completion_tokens"),
        "finish_reason": choice.get("finish_reason"),
    }


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## Models you can use

    - **`qwen3-8b-wnc`**: Qwen3-8B with a LoRA adapter we trained on the WNC training split, hosted by us. (`qwen3-8b`, the same model without the adapter, is also available.) The server sleeps when it hasn't been used for a while and takes about 2 minutes to wake up, so click **Wake / check** a few minutes before your first run.
    - **Claude Haiku 5.5 and Opus 5.5**, through Anthropic's API with your own key. If you don't have one, ask us for one on Piazza.

    Put your keys in a file named `.env` in the same folder as this notebook, and never paste a key into the notebook itself:

    ```
    LAB4_COURSE_API_KEY=<the course key from Piazza>
    ANTHROPIC_API_KEY=<your Anthropic key>
    ```
    """)
    return


@app.cell(hide_code=True)
def _():
    load_env_file(mo.notebook_dir() / ".env")
    _status = {e: endpoint_config(e)["missing"] for e in ("course", "llm")}
    wake_button = mo.ui.run_button(label="Wake / check both endpoints")
    mo.vstack([
        mo.md(" · ".join(f"**{e}:** " + ("configured" if not m else "missing " + ", ".join(f"`{x}`" for x in m))
                         for e, m in _status.items())),
        wake_button,
    ])
    return (wake_button,)


@app.cell(hide_code=True)
def _(wake_button):
    mo.stop(not wake_button.value)
    _lines = []
    for _endpoint, _model in (("course", "qwen3-8b"), ("llm", "claude-haiku-5-5")):
        if endpoint_config(_endpoint)["missing"]:
            _lines.append(f"- **{_endpoint}:** not configured")
            continue
        _t0 = time.perf_counter()
        try:
            _r = call_model("Reply with the single word: ready", {"max_output_tokens": 5}, _endpoint, _model)
            _lines.append(f"- **{_endpoint}:** answered `{_r['raw_output']!r}` after {time.perf_counter() - _t0:.0f} s")
        except Exception as _e:
            _lines.append(f"- **{_endpoint}:** failed after {time.perf_counter() - _t0:.0f} s: `{_e}`")
    mo.md("\n".join(_lines))
    return


@app.cell(hide_code=True)
def _():
    RUNS_DIR = mo.notebook_dir() / "lab4_runs"  # one JSON file per run; reopen the notebook and results are still here
    CKPT_DIR = mo.notebook_dir() / "lab4_ckpts"  # trained bert-mini weights (Q6); not submitted
    get_runs_version, set_runs_version = mo.state(0)  # bumped after each saved run so the results table refreshes
    return CKPT_DIR, RUNS_DIR, get_runs_version, set_runs_version


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Run a model on the evaluation sentences

    Choose a model and, for Claude models, a thinking effort and whether to constrain the output to `biased`/`neutral`. You can edit the instructions and add demonstrations, which are drawn from the dev split (the seed picks which ones). The starter instructions are exactly the prompt `qwen3-8b-wnc` was trained with, so use them unchanged, with no demonstrations, when running `qwen3-8b-wnc`. Each run classifies 400 sentences; the results table shows its accuracy and estimated cost.
    """)
    return


@app.cell(hide_code=True)
def _():
    STARTER_INSTRUCTIONS = ('Label the sentence as "biased" or "neutral" according to Wikipedia\'s Neutral Point of View '
                            'policy. Answer with one word.')
    icl_target = mo.ui.dropdown({"qwen3-8b-wnc (trained on WNC)": ("course", "qwen3-8b-wnc"), "qwen3-8b (no adapter)": ("course", "qwen3-8b"),
                                 "Claude Haiku 5.5": ("llm", "claude-haiku-5-5"),
                                 "Claude Opus 5.5": ("llm", "claude-opus-5-5")}, value="Claude Haiku 5.5", label="Model")
    icl_effort = mo.ui.dropdown(["low", "medium", "high"], value="low", label="Thinking effort (Claude)")
    icl_json = mo.ui.checkbox(label="Constrain output to biased/neutral (Claude)")
    icl_instructions = mo.ui.text_area(value=STARTER_INSTRUCTIONS, label="Instructions", full_width=True, rows=4)
    icl_k = mo.ui.slider(0, 16, step=2, value=0, label="Demonstrations")
    icl_seed = mo.ui.number(0, 10_000, value=0, label="Demonstration seed")
    icl_name = mo.ui.text(value="", placeholder="e.g. my-instructions-v1", label="Short name for this run")
    mo.vstack([mo.hstack([icl_target, icl_effort, icl_json], justify="start"),
               mo.hstack([icl_k, icl_seed, icl_name], justify="start"), icl_instructions])
    return (
        STARTER_INSTRUCTIONS,
        icl_effort,
        icl_instructions,
        icl_json,
        icl_k,
        icl_name,
        icl_seed,
        icl_target,
    )


@app.cell(hide_code=True)
def _(DEMO_POOL, EVAL_SET, icl_instructions, icl_k, icl_seed):
    icl_demos = select_demos(DEMO_POOL, icl_k.value, icl_seed.value)
    ICL_TEMPLATE = icl_instructions.value.strip() + "\n\n{demonstrations}Sentence: {text}\nLabel:"
    mo.vstack([
        mo.md(f"Prompt for the first evaluation sentence (demonstrations: `{', '.join(icl_demos['pair_id']) or 'none'}`):"),
        mo.plain_text(format_prompt(ICL_TEMPLATE, EVAL_SET["text"].iloc[0], icl_demos)),
    ])
    return ICL_TEMPLATE, icl_demos


@app.cell(hide_code=True)
def _(icl_target):
    icl_button = mo.ui.run_button(label="Run on the 400 evaluation sentences",
                                  disabled=bool(endpoint_config(icl_target.value[0])["missing"]))
    icl_button
    return (icl_button,)


@app.cell(hide_code=True)
def _(
    EVAL_SET,
    ICL_TEMPLATE,
    RUNS_DIR,
    STARTER_INSTRUCTIONS,
    icl_button,
    icl_demos,
    icl_effort,
    icl_instructions,
    icl_json,
    icl_k,
    icl_name,
    icl_seed,
    icl_target,
    set_runs_version,
):
    mo.stop(not icl_button.value)
    _endpoint, _model = icl_target.value
    _model_id = _model
    _starter = icl_instructions.value.strip() == STARTER_INSTRUCTIONS
    _claude = _endpoint == "llm"
    _settings = {"endpoint": _endpoint, "template": ICL_TEMPLATE, "starter_instructions": _starter,
                 "k": icl_k.value, "demo_seed": icl_seed.value, "demo_pair_ids": list(icl_demos["pair_id"]),
                 "temperature": 0, "max_output_tokens": 64 if _claude else 3,
                 **({"effort": icl_effort.value, "json_label": icl_json.value} if _claude else {})}
    _name = icl_name.value.strip() or (f"{_model_id}-k{icl_k.value}-{'starter' if _starter else 'custom'}"
                                       + (f"-{icl_effort.value}" if _claude else "")
                                       + ("-json" if _claude and icl_json.value else ""))
    _record = run_classifier(
        _name, f"{_endpoint}:{_model_id}",
        ("trained (LoRA on WNC train)" if _model == "qwen3-8b-wnc" else "in-context") + f", k={icl_k.value}", _settings,
        lambda _text: call_model(format_prompt(ICL_TEMPLATE, _text, icl_demos), _settings, _endpoint, _model), EVAL_SET,
        workers=8)
    _saved = save_run(_record, RUNS_DIR)
    set_runs_version(lambda v: v + 1)
    mo.md(f"Saved `{_saved}`" + (" — **stopped early after repeated errors; see the `error` field.**" if _record["stopped_early"] else ""))
    return


@app.cell(hide_code=True)
def _(EVAL_SET, RUNS_DIR, get_runs_version):
    get_runs_version()  # rerun after each saved run
    all_runs = {r["run_id"]: r for r in load_runs(RUNS_DIR) if r.get("kind", "classify") == "classify"}
    _rows = []
    for _r in all_runs.values():
        _preds = pd.DataFrame(_r["predictions"], columns=["sentence_id", "parsed_label", "error", "latency_s",
                                                          "input_tokens", "output_tokens"])
        _s = score_predictions(_preds, EVAL_SET)
        _rows.append({"name": _r["name"], "model": _r["model"], "adaptation": _r["adaptation"], **_s,
                      "errors": int(_preds["error"].notna().sum()),
                      "input_tokens_per_item": _preds["input_tokens"].mean(),
                      "output_tokens_per_item": _preds["output_tokens"].mean(),
                      "est_cost_usd": claude_cost(_r["model"], _preds["input_tokens"], _preds["output_tokens"]),
                      "est_cost_per_1000_usd": (round(claude_cost(_r["model"], _preds["input_tokens"], _preds["output_tokens"])
                                                      / len(_preds) * 1000, 3)
                                                if claude_cost(_r["model"], _preds["input_tokens"], _preds["output_tokens"]) is not None
                                                and len(_preds) else None),
                      "wall_time_s": _r.get("wall_time_s"), "run_id": _r["run_id"]})
    results_table = pd.DataFrame(_rows)
    mo.vstack([
        mo.md(f"### Results on the fixed evaluation subset ({len(EVAL_SET)} sentences)"),
        mo.ui.table(results_table.round(3), selection=None) if _rows else mo.md("_No saved runs yet._"),
        mo.md("`accuracy` counts invalid and missing outputs as wrong. `pairs_both_correct` = share of test pairs where "
              "both sentences got the right label. Intervals reflect sampling of evaluation items only, not run-to-run variation."),
    ])
    return (all_runs,)


@app.cell
def _(all_runs):
    _ids = list(all_runs)
    compare_a = mo.ui.dropdown(_ids, value=_ids[0] if _ids else None, label="Run A")
    compare_b = mo.ui.dropdown(_ids, value=_ids[-1] if _ids else None, label="Run B")
    mo.vstack([mo.md("### Paired comparison (same evaluation items)"), mo.hstack([compare_a, compare_b], justify="start")])
    return compare_a, compare_b


@app.cell(hide_code=True)
def _(EVAL_SET, all_runs, compare_a, compare_b, pairs):
    mo.stop(not (compare_a.value and compare_b.value), mo.md("_Save at least one run to compare._"))
    _g = EVAL_SET[["sentence_id", "text", "label"]].copy()
    for _col, _rid in (("A", compare_a.value), ("B", compare_b.value)):
        _p = pd.DataFrame(all_runs[_rid]["predictions"])[["sentence_id", "parsed_label"]].rename(columns={"parsed_label": _col})
        _g = _g.merge(_p, on="sentence_id", how="left")
    _a_ok, _b_ok = _g["A"] == _g["label"], _g["B"] == _g["label"]
    _table = pd.DataFrame({"B correct": [int((_a_ok & _b_ok).sum()), int((~_a_ok & _b_ok).sum())],
                           "B wrong": [int((_a_ok & ~_b_ok).sum()), int((~_a_ok & ~_b_ok).sum())]},
                          index=["A correct", "A wrong"])
    _disagree = describe_sentences(_g[_a_ok != _b_ok], pairs)
    mo.vstack([
        mo.ui.table(_table.reset_index(names=""), selection=None),
        mo.md(f"The runs disagree on **{len(_disagree)}** of {len(_g)} sentences. Only these can show a difference between A and B."),
        mo.ui.table(_disagree, selection=None, page_size=10),
    ])
    return


@app.cell(hide_code=True)
def _():
    _path = mo.notebook_dir() / "data" / "tuned_curve.csv"
    if not _path.exists():
        _out = mo.md("_Learning curve for `qwen3-8b-wnc`: not available yet._")
    else:
        from matplotlib import pyplot as plt
        _c = pd.read_csv(_path)
        _fig, _ax = plt.subplots(figsize=(6, 3.2))
        _ax.plot(_c["examples_seen"], _c["dev_acc"], marker="o", label="dev accuracy")
        _ax.axhline(0.5, color="grey", lw=0.8, ls="--")
        _ax.set_xlabel("training sentences seen")
        _ax.set_ylabel("accuracy")
        _ax.set_title("qwen3-8b-wnc: learning curve on dev (step 0 = untrained model)")
        _ax.legend(loc="lower right")
        _out = _fig
    _out
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 5: Which model, and what does it take to make it work? `[INDIVIDUAL]`

    We trained a LoRA adapter for Qwen3-8B on the WNC training split. It is `qwen3-8b-wnc` in the model menu above (learning curve also plotted above). Start by classifying the 400 evaluation sentences with `qwen3-8b-wnc` (this one is free).

    **a)** Classify the 400 evaluation sentences with Claude Haiku 5.5 using the starter instructions. Then try two training-free changes, one at a time: for example, demonstrations, instructions you write yourself, a higher thinking effort, or constrained output. Which helped, and how close did your best setting get to `qwen3-8b-wnc`?

    **b)** Classify the 400 evaluation sentences with Claude Opus 5.5 using the starter instructions, and compare its accuracy with `qwen3-8b-wnc`.

    We trained `qwen3-8b-wnc` by fine-tuning a rank-16 LoRA adapter for Qwen3-8B on all 53,772 training pairs (107,544 sentences) for one epoch. Training took about 32 minutes on two NVIDIA L40S GPUs, which is about 1.1 GPU-hours. When kept busy, one L40S serves about 170 classifications per second.

    1. Choose a cloud platform that rents NVIDIA L40S GPUs, name it, and look up its on-demand hourly price. How much did it cost to train `qwen3-8b-wnc`?
    2. What is the cost per 1,000 classifications for Opus 5.5? The results table shows it, using Anthropic's prices for Opus 5.5 of $4 per million input tokens and $20 per million output tokens. What is it for `qwen3-8b-wnc`, based on the same hourly price and the throughput above?
    3. If the one-time training cost is amortized over all the classifications you run, after how many classifications does `qwen3-8b-wnc` become cheaper overall than Opus 5.5?

    All of these runs together should cost a few dollars at most. The results table shows each run's token counts and estimated cost.
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # a) your Haiku runs, what helped, how close to qwen3-8b-wnc; b) Opus vs qwen3-8b-wnc accuracy, platform + price, training cost, cost per 1,000 for each, amortized breakeven.
    answer_5 = PLACEHOLDER
    mo.md(answer_5)
    return (answer_5,)


@app.function
def describe_sentences(df: pd.DataFrame, pairs: pd.DataFrame) -> pd.DataFrame:
    """Add descriptive columns to a table of sentences (needs sentence_id, text): length, the editor's change
    for the sentence's pair, and whether the pair is a label-conflict pair."""
    out = df.copy()
    out["pair_id"] = out["sentence_id"].str.rsplit("-", n=1).str[0]
    info = pairs.set_index("pair_id")
    def _change(pid):
        r = info.loc[pid]
        a, b = r["biased_text"].split(), r["neutral_text"].split()
        parts = []
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
            if op != "equal":
                parts.append(f"{' '.join(a[i1:i2]) or '∅'} → {' '.join(b[j1:j2]) or '∅'}")
        return "; ".join(parts)
    out["words"] = out["text"].str.split().str.len()
    out["editor_change"] = out["pair_id"].map(_change)
    out["label_conflict"] = out["pair_id"].map(info["label_conflict"])
    return out.drop(columns=["pair_id"])


@app.function
def bert_run_label(cfg: dict) -> str:
    """Readable, unique name for a bert-mini run, e.g. bs32_lr0.0001_16kpairs_ep1_seed0."""
    k = cfg["n_train_pairs"]
    size = f"{k // 1000}k" if k % 1000 == 0 else str(k)
    return (f"bs{cfg['batch_size']}_lr{cfg['lr']:g}_{size}pairs_ep{cfg['epochs']}"
            + ("_noconflict" if cfg["drop_conflicts"] else "") + f"_seed{cfg['seed']}")


@app.function
def budget_used(cfg: dict) -> int:
    """Training sentences processed: 2 sentences per pair, per epoch."""
    return 2 * cfg["n_train_pairs"] * cfg["epochs"]


@app.function
def train_bert_mini(cfg: dict, train_pairs: pd.DataFrame, test: pd.DataFrame, out_dir, progress=None,
                    ckpt_dir=None) -> dict:
    """Train bert-mini with `cfg`, evaluate on `test`, save metrics and predictions to `out_dir` and the weights to `ckpt_dir` (if given), return the metrics.

    If out_dir already holds a finished run (metrics.json), nothing is trained and the saved metrics are returned.
    metrics.json is written last, so an interrupted run is simply retrained next time.
    Device: LAB4_DEVICE if set, else CUDA, else Apple GPU (mps), else CPU.
    """
    if (out_dir / "metrics.json").exists():
        return json.loads((out_dir / "metrics.json").read_text())
    import torch
    from transformers import AutoTokenizer, BertConfig, BertForSequenceClassification

    pool = train_pairs[~train_pairs["label_conflict"]] if cfg["drop_conflicts"] else train_pairs
    rng = random.Random(cfg["seed"])
    torch.manual_seed(cfg["seed"])
    order = list(range(len(pool)))
    rng.shuffle(order)
    sub = pool.iloc[order[:cfg["n_train_pairs"]]]
    X = list(sub["biased_text"]) + list(sub["neutral_text"])
    y = [1] * len(sub) + [0] * len(sub)

    device = os.environ.get("LAB4_DEVICE") or (
        "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained("google-bert/bert-base-uncased")  # bert-mini's own tokenizer files are broken
    hf = "prajjwal1/bert-mini"
    model = BertForSequenceClassification.from_pretrained(hf, config=BertConfig.from_pretrained(hf, num_labels=2)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=0.01)
    bs = cfg["batch_size"]
    steps = cfg["epochs"] * math.ceil(len(X) / bs)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: max(0.0, 1 - s / steps))  # linear decay to 0

    t0, step = time.perf_counter(), 0
    model.train()
    for _ in range(cfg["epochs"]):
        idx = list(range(len(X)))
        rng.shuffle(idx)
        for b in range(0, len(idx), bs):
            bi = idx[b:b + bs]
            enc = tok([X[i] for i in bi], return_tensors="pt", padding=True, truncation=True, max_length=128).to(device)
            loss = model(**enc, labels=torch.tensor([y[i] for i in bi], device=device)).loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step(); opt.zero_grad()
            step += 1
            if progress:
                progress()
    train_s = time.perf_counter() - t0

    model.eval()
    probs = []
    with torch.no_grad():
        for b in range(0, len(test), 128):
            enc = tok(list(test["text"].iloc[b:b + 128]), return_tensors="pt", padding=True, truncation=True,
                      max_length=128).to(device)
            probs.append(torch.softmax(model(**enc).logits.float(), -1)[:, 1].cpu().numpy())
    p1 = np.concatenate(probs)
    pred = np.where(p1 >= 0.5, "biased", "neutral")
    k, n = int((pred == test["label"].to_numpy()).sum()), len(test)
    lo, hi = wilson_ci(k, n)

    out_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"sentence_id": test["sentence_id"], "label": test["label"], "pred": pred,
                  "p_biased": p1.round(4)}).to_csv(out_dir / "test_predictions.csv", index=False)
    if ckpt_dir is not None:  # weights live outside lab4_runs so that folder stays small enough to submit
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        torch.save({k_: v.half() for k_, v in model.state_dict().items()}, ckpt_dir / "model.pt")
    metrics = {"label": bert_run_label(cfg), "config": cfg, "accuracy": k / n, "acc_95ci": [lo, hi],
               "pred_biased_rate": float((pred == "biased").mean()), "steps": steps, "train_s": round(train_s, 1),
               "device": device, "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=1))
    return metrics


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ## Train a small classifier

    You'll train bert-mini, an 11-million-parameter BERT model, on your own computer. Each run trains on part of the WNC training split and is scored on all 2,000 test sentences (more than Part I's 400, so the test interval is narrower and differences between settings are easier to see).

    **Budget:** a run may process at most 32,000 training sentences, counted as pairs × 2 × epochs. For example, 16,000 pairs for one epoch, or 8,000 pairs for two. On a recent laptop CPU one full-budget run at the default batch size takes roughly 4–5 minutes, and smaller batches take longer. An Apple GPU (recent Macs) or a CUDA GPU is used automatically if you have one, and a run then takes about a minute.

    **Saving:** every run's results are saved in `lab4_runs/bert/` (and its weights in `lab4_ckpts/`) under a name built from its settings, e.g. `bs32_lr0.0001_16kpairs_ep1_seed0`. If you ask for a run that already exists, its results (accuracy and predictions) are loaded from the saved record instead of training the model again, so you can stop and come back later.

    **Training from a terminal:** the notebook is busy while it trains, so it's often easier to run `python train_bert.py` in a terminal (see `python train_bert.py --help` for the settings; for example `python train_bert.py --batch-size 32 --seeds 0 1 2`). Runs started there show up in the tables below after you click **Refresh**.

    **Default setting:** batch size 256, learning rate 0.0001, 16,000 pairs, 1 epoch, all pairs. The form below starts there.

    When training starts you'll see a load report listing some weights as UNEXPECTED and some as MISSING ("newly initialized"). That's expected: the unexpected ones belong to bert-mini's pretraining heads, which we drop, and the missing ones are the new classification layer, which is exactly what training learns.
    """)
    return


@app.cell(hide_code=True)
def _():
    # Default = batch 256, lr 1e-4, 16k pairs, 1 epoch.
    BERT_BUDGET = 32_000
    bert_form = mo.ui.dictionary({
        "n_train_pairs": mo.ui.number(500, 53_772, step=500, value=16_000, label="Training pairs"),
        "epochs": mo.ui.number(1, 8, value=1, label="Epochs"),
        "batch_size": mo.ui.dropdown([8, 16, 32, 64, 128, 256], value=256, label="Batch size"),
        "lr": mo.ui.dropdown({"1e-5": 1e-5, "3e-5": 3e-5, "1e-4": 1e-4, "3e-4": 3e-4, "1e-3": 1e-3}, value="1e-4",
                             label="Learning rate"),
        "drop_conflicts": mo.ui.checkbox(label="Leave out label-conflict pairs"),
        "seeds": mo.ui.text(value="0, 1, 2", label="Seeds (comma-separated)"),
    })
    bert_form
    return BERT_BUDGET, bert_form


@app.cell(hide_code=True)
def _(BERT_BUDGET, bert_form):
    _v = bert_form.value
    bert_seeds = [int(x) for x in re.findall(r"\d+", _v["seeds"])]
    bert_cfgs = [{"n_train_pairs": int(_v["n_train_pairs"]), "epochs": int(_v["epochs"]),
                  "batch_size": int(_v["batch_size"]), "lr": float(_v["lr"]),
                  "drop_conflicts": bool(_v["drop_conflicts"]), "seed": _s} for _s in bert_seeds]
    _used = budget_used(bert_cfgs[0]) if bert_cfgs else 0
    _ok = bool(bert_cfgs) and _used <= BERT_BUDGET
    bert_button = mo.ui.run_button(label=f"Train {len(bert_cfgs)} run(s)", disabled=not _ok)
    mo.vstack([
        mo.md(f"This setting uses **{_used:,}** of {BERT_BUDGET:,} training sentences per run."
              + ("" if _ok else " **Over budget, or no seeds given.**")),
        bert_button,
    ])
    return bert_button, bert_cfgs


@app.cell(hide_code=True)
def _(
    CKPT_DIR,
    RUNS_DIR,
    TRAIN_PAIRS,
    bert_button,
    bert_cfgs,
    sentences,
    set_runs_version,
):
    mo.stop(not bert_button.value)
    _test = sentences[sentences["split"] == "test"].reset_index(drop=True)
    _rows = []
    for _cfg in bert_cfgs:
        _dir = RUNS_DIR / "bert" / bert_run_label(_cfg)
        _steps = _cfg["epochs"] * math.ceil(2 * _cfg["n_train_pairs"] / _cfg["batch_size"])
        if (_dir / "metrics.json").exists():
            _m, _how = train_bert_mini(_cfg, TRAIN_PAIRS, _test, _dir), "loaded"
        else:
            with mo.status.progress_bar(total=_steps, title=bert_run_label(_cfg)) as _bar:
                _m = train_bert_mini(_cfg, TRAIN_PAIRS, _test, _dir, progress=_bar.update,
                                     ckpt_dir=CKPT_DIR / bert_run_label(_cfg))
            _how = "trained"
        _rows.append({"run": _m["label"], "accuracy": round(_m["accuracy"], 4),
                      "95% interval": f"[{_m['acc_95ci'][0]:.3f}, {_m['acc_95ci'][1]:.3f}]",
                      "predicted biased": round(_m["pred_biased_rate"], 3), "train_s": _m["train_s"], "": _how})
    set_runs_version(lambda v: v + 1)
    mo.ui.table(pd.DataFrame(_rows), selection=None)
    return


@app.cell(hide_code=True)
def _():
    bert_refresh = mo.ui.button(label="Refresh (pick up runs from the terminal)", value=0, on_click=lambda v: v + 1)
    bert_refresh
    return (bert_refresh,)


@app.cell(hide_code=True)
def _(RUNS_DIR, bert_refresh, get_runs_version):
    get_runs_version()
    bert_refresh.value  # rerun when clicked
    bert_runs = {}
    for _f in sorted((RUNS_DIR / "bert").glob("*/metrics.json")) if (RUNS_DIR / "bert").exists() else []:
        _m = json.loads(_f.read_text())
        bert_runs[_m["label"]] = {**_m, "dir": _f.parent}
    _rows = []
    for _lab, _m in bert_runs.items():
        _rows.append({"setting": re.sub(r"_seed\d+$", "", _lab), "seed": _m["config"]["seed"], "accuracy": _m["accuracy"]})
    _df = pd.DataFrame(_rows)
    if len(_df):
        _summary = (_df.groupby("setting")["accuracy"].agg(["count", "mean", "min", "max"])
                    .rename(columns={"count": "seeds"}).round(4).reset_index())
        _out = mo.vstack([mo.md("### Your saved bert-mini runs (test accuracy, 2,000 sentences)"),
                          mo.ui.table(_summary, selection=None)])
    else:
        _out = mo.md("_No saved bert-mini runs yet._")
    _out
    return (bert_runs,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    **Is a difference real?** Your test accuracy is measured on 2,000 sentences, a sample of all the sentences you could have tested on. With a different 2,000, the number would shift a little; the 95% interval next to each run shows how much, about two points either way here. Training has randomness too: changing only the seed gives a different model, and its accuracy can move by more than that. Before calling one setting better than another, check that the gap holds across seeds and is bigger than the interval.
    """)
    return


@app.cell(hide_code=True)
def _(bert_runs):
    _ids = list(bert_runs)
    bert_a = mo.ui.dropdown(_ids, value=_ids[0] if _ids else None, label="Run A")
    bert_b = mo.ui.dropdown(_ids, value=_ids[-1] if _ids else None, label="Run B")
    mo.hstack([bert_a, bert_b], justify="start")
    return bert_a, bert_b


@app.cell(hide_code=True)
def _(bert_a, bert_b, bert_runs, pairs, sentences):
    mo.stop(not (bert_a.value and bert_b.value), mo.md("_Train at least one run to compare._"))
    _g = sentences[sentences["split"] == "test"][["sentence_id", "text", "label"]]
    for _col, _lab in (("A", bert_a.value), ("B", bert_b.value)):
        _p = pd.read_csv(bert_runs[_lab]["dir"] / "test_predictions.csv")[["sentence_id", "pred"]].rename(columns={"pred": _col})
        _g = _g.merge(_p, on="sentence_id", how="left")
    _a_ok, _b_ok = _g["A"] == _g["label"], _g["B"] == _g["label"]
    _dis = describe_sentences(_g[_a_ok != _b_ok], pairs)
    _dis["right"] = np.where(_dis["A"] == _dis["label"], "A", "B")
    _by_label = _dis.groupby(["label", "right"]).size().unstack(fill_value=0)
    mo.vstack([
        mo.md(f"A and B disagree on **{len(_dis)}** of {len(_g)} test sentences: A is right on "
              f"{int((_dis['right'] == 'A').sum())}, B on {int((_dis['right'] == 'B').sum())}. By true label:"),
        mo.ui.table(_by_label.reset_index(), selection=None),
        mo.ui.table(_dis[["sentence_id", "text", "label", "A", "B", "words", "editor_change", "label_conflict"]],
                    selection=None, page_size=10),
    ])
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 6: Better and worse training settings `[INDIVIDUAL]`

    Start from the default setting. You may change the batch size, learning rate, epochs, and how many and which training pairs you use, as long as each run stays within the budget and uses bert-mini.

    *Hint:* every full-budget run processes the same number of training sentences, so settings differ mainly in how many update steps they take and how big each step is. Think about which of those the default might be getting wrong.

    **a)** Find one setting that is clearly better than the default and one that is clearly worse. Train the default and your better setting with three seeds each, and the worse setting with one seed. Report their test accuracies and say whether the improvement holds up across seeds and is larger than the test interval.

    **b)** Explain why your better setting helps and why your worse setting hurts.

    **c)** Look at the sentences where seed 0 of the default and seed 0 of your better setting disagree. In one or two sentences, describe one difference you notice between the sentences each model gets wrong.
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # a) three settings x seeds with accuracies; b) why each change helps or hurts; c) what differs in the disagreements, with sentence IDs.
    answer_6 = PLACEHOLDER
    mo.md(answer_6)
    return (answer_6,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    # Rewriting biased sentences

    A classifier score alone does not tell us whether a rewrite is useful. We will inspect generated rewrites for neutral wording, preservation of meaning, and unnecessary edits, alongside the source and editor reference.
    """)
    return


@app.function
def word_edit_count(before: str, after: str) -> int:
    """Number of words removed or added going from `before` to `after` (a size-of-edit proxy, not a quality score).
    Ignores capitalization."""
    a, b = before.lower().split(), after.lower().split()
    n = 0
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
        if op != "equal":
            n += (i2 - i1) + (j2 - j1)
    return n


@app.function
def run_rewriter(name: str, model: str, settings: dict, generate_fn, items: pd.DataFrame,
                 max_consecutive_errors: int = 5) -> dict:
    """Generate one rewrite per item and return a run record (saved with save_run, like classification runs).

    items: DataFrame with pair_id, source, reference.
    generate_fn(source) -> str, or dict with raw_output and optionally input_tokens / output_tokens / finish_reason.
    """
    rows, streak, t_start = [], 0, time.perf_counter()
    for r in items.itertuples():
        if streak >= max_consecutive_errors:
            break
        t0, err, out = time.perf_counter(), None, {}
        try:
            res = generate_fn(r.source)
            out = res if isinstance(res, dict) else {"raw_output": res}
            streak = 0
        except Exception as e:
            err, streak = f"{type(e).__name__}: {e}", streak + 1
        rewrite = (out.get("raw_output") or "").strip()
        rows.append({
            "pair_id": r.pair_id,
            "source": r.source,
            "reference": r.reference,
            "rewrite": rewrite,
            "error": err,
            "finish_reason": out.get("finish_reason"),
            "latency_s": round(time.perf_counter() - t0, 4),
            "input_tokens": out.get("input_tokens"),
            "output_tokens": out.get("output_tokens"),
        })
    now = datetime.now(timezone.utc)
    return {
        "run_id": f"{now:%Y%m%dT%H%M%SZ}-{re.sub(r'[^A-Za-z0-9_-]+', '-', name)}",
        "kind": "rewrite",
        "name": name,
        "created_utc": now.isoformat(timespec="seconds"),
        "model": model,
        "settings": settings,
        "n_items": len(items),
        "n_attempted": len(rows),
        "stopped_early": len(rows) < len(items),
        "wall_time_s": round(time.perf_counter() - t_start, 2),
        "rewrites": rows,
    }


@app.cell
def _():
    REWRITE_TEMPLATE = (
        "Here is a sentence from a Wikipedia article. Rewrite it so that it follows Wikipedia's Neutral Point of View "
        "policy: remove or replace wording that takes a side, praises or disparages, or presents a disputed claim as "
        "fact. Keep everything else the same, including the facts, names and sentence structure, and change as few "
        "words as possible. Reply with the rewritten sentence only.\n\n"
        "Sentence: {text}"
    )
    # Everyone rewrites the same 10 biased sentences (chosen with a fixed seed from the evaluation subset).
    REWRITE_IDS = ['test-00563', 'test-00175', 'test-00759', 'test-00788', 'test-00486', 'test-00606', 'test-00192', 'test-00149', 'test-00124', 'test-00796']
    mo.md("""
    ### Generate rewrites

    Everyone rewrites the same 10 `biased` sentences from the evaluation subset. The editor's actual rewrite is shown next to each one for comparison. Each run is saved to `lab4_runs/`, so you can come back to it later.
    """)
    return REWRITE_IDS, REWRITE_TEMPLATE


@app.cell(hide_code=True)
def _(REWRITE_IDS, REWRITE_TEMPLATE, pairs):
    REWRITE_ITEMS = (pairs.set_index("pair_id").loc[REWRITE_IDS, ["biased_text", "neutral_text"]]
                     .rename(columns={"biased_text": "source", "neutral_text": "reference"}).reset_index())
    mo.vstack([
        mo.md("Prompt for the first sentence:"),
        mo.plain_text(REWRITE_TEMPLATE.format(text=REWRITE_ITEMS["source"].iloc[0])),
    ])
    return (REWRITE_ITEMS,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    If you want to see how the prompt itself may influence model behavior, feel free to edit this prompt in the code cell above after answering the question!
    """)
    return


@app.cell
def _():
    rewrite_max_tokens = mo.ui.number(16, 512, value=200, label="Max output tokens (Haiku only)")
    rewrite_model = mo.ui.dropdown({"Claude Haiku 5.5": "claude-haiku-5-5",
                                    "Claude Opus 5.5": "claude-opus-5-5"}, value="Claude Opus 5.5", label="Model")
    rewrite_classify = mo.ui.checkbox(label="Optional: also have `qwen3-8b-wnc` label each rewrite and editor's rewrite",
                                      disabled=bool(endpoint_config("course")["missing"]))
    rewrite_button = mo.ui.run_button(label="Generate rewrites",
                                      disabled=bool(endpoint_config("llm")["missing"]))
    mo.vstack([mo.hstack([rewrite_model, rewrite_max_tokens, rewrite_button], justify="start"), rewrite_classify])
    return rewrite_button, rewrite_classify, rewrite_max_tokens, rewrite_model


@app.cell
def _(
    REWRITE_ITEMS,
    REWRITE_TEMPLATE,
    RUNS_DIR,
    STARTER_INSTRUCTIONS,
    rewrite_button,
    rewrite_classify,
    rewrite_max_tokens,
    rewrite_model,
    set_runs_version,
):
    mo.stop(not rewrite_button.value)
    _settings = {"template": REWRITE_TEMPLATE, "effort": "low", "max_output_tokens": rewrite_max_tokens.value,
                 "pair_ids": list(REWRITE_ITEMS["pair_id"])}
    _record = run_rewriter(
        f"rewrite-{rewrite_model.value}", rewrite_model.value, _settings,
        lambda _src: call_model(REWRITE_TEMPLATE.format(text=_src), _settings, "llm", rewrite_model.value), REWRITE_ITEMS)
    if rewrite_classify.value:  # optional: the course's trained detector labels each rewrite and each editor rewrite
        _cls = {"temperature": 0, "max_output_tokens": 3}
        _ask = lambda _t: parse_label(call_model(f"{STARTER_INSTRUCTIONS}\n\nSentence: {_t}\nLabel:", _cls,
                                                 "course", "qwen3-8b-wnc")["raw_output"])
        for _row in _record["rewrites"]:
            for _key, _text in (("tuned_rewrite", _row["rewrite"]), ("tuned_reference", _row["reference"])):
                try:
                    _row[_key] = _ask(_text) if _text else None
                except Exception as _e:
                    _row[_key] = f"error: {_e}"
        _record["settings"]["classified_by"] = "course:qwen3-8b-wnc"
    rewrite_saved = save_run(_record, RUNS_DIR)
    set_runs_version(lambda v: v + 1)
    mo.md(f"Saved `{rewrite_saved}`" + (" — **stopped early after repeated errors; see the `error` field.**" if _record["stopped_early"] else ""))
    return


@app.cell
def _(RUNS_DIR, get_runs_version):
    get_runs_version()
    rewrite_runs = {r["run_id"]: r for r in load_runs(RUNS_DIR) if r.get("kind") == "rewrite"}
    _ids = list(rewrite_runs)
    review_run = mo.ui.dropdown(_ids, value=_ids[-1] if _ids else None, label="Rewrite run to review")
    mo.vstack([mo.md("### Review rewrites"), review_run])
    return review_run, rewrite_runs


@app.cell(hide_code=True)
def _(review_run, rewrite_runs):
    mo.stop(not review_run.value, mo.md("_No rewrite runs saved yet._"))
    _rec = rewrite_runs[review_run.value]
    review_df = pd.DataFrame(_rec["rewrites"])
    review_df["status"] = np.select(
        [review_df["error"].notna(), review_df["rewrite"] == "", review_df["rewrite"].str.lower().str.split().str.join(" ") == review_df["source"].str.lower().str.split().str.join(" ")],
        ["call failed", "empty output", "unchanged"], default="ok")
    review_df["editor_words_changed"] = [word_edit_count(s, r) for s, r in zip(review_df["source"], review_df["reference"])]
    review_df["model_words_changed"] = [word_edit_count(s, r) for s, r in zip(review_df["source"], review_df["rewrite"])]
    _status_counts = review_df["status"].value_counts().to_dict()
    _rows = "".join(
        f"<tr><td style='vertical-align:top;white-space:nowrap'><code>{_r.pair_id}</code><br><small>{_r.status}</small></td>"
        f"<td style='vertical-align:top'>{html.escape(_r.source)}</td>"
        f"<td style='vertical-align:top'>{word_diff_html(_r.source, _r.reference)}<br><small>{_r.editor_words_changed} words changed"
        f"{'; qwen3-8b-wnc: ' + str(getattr(_r, 'tuned_reference')) if 'tuned_reference' in review_df else ''}</small></td>"
        f"<td style='vertical-align:top'>{word_diff_html(_r.source, _r.rewrite) if _r.rewrite else '<i>(none)</i>'}"
        f"<br><small>{_r.model_words_changed} words changed"
        f"{'; qwen3-8b-wnc: ' + str(getattr(_r, 'tuned_rewrite')) if 'tuned_rewrite' in review_df else ''}</small></td></tr>"
        for _r in review_df.itertuples())
    mo.vstack([
        mo.md(f"Run `{_rec['run_id']}`, model `{_rec['model']}`, {len(review_df)} of {_rec['n_items']} items, "
              f"statuses: {_status_counts}. Median words changed: editor {review_df['editor_words_changed'].median():.0f}, "
              f"model {review_df['model_words_changed'].median():.0f}."),
        mo.md("Diffs are against the **source** and ignore capitalization. The number of words changed is only a "
              "size-of-edit proxy: it says nothing about whether the edit was correct, and a different rewrite from the "
              "editor's can still be good. If you turned on the optional `qwen3-8b-wnc` labels, remember the detector is right "
              "about three times in four on single sentences; your own judgment is the evidence that counts."),
        mo.Html("<table><thead><tr><th>pair_id</th><th>source (biased)</th><th>editor's rewrite (reference)</th>"
                f"<th>model rewrite</th></tr></thead><tbody>{_rows}</tbody></table>"),
        mo.md("**For your answer to Question 7:** copy the block below into your answer cell."),
        mo.plain_text(f"Model: {_rec['model']}\n\n" + "\n\n".join(
            f"{_r.pair_id}\n  source:  {_r.source}\n  editor:  {_r.reference}\n  model:   {_r.rewrite or '(no output)'}"
            for _r in review_df.itertuples())),
    ])
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 7: Generate and evaluate neutral rewrites `[INDIVIDUAL]`

    Generate rewrites for the 10 assigned sentences above with either Claude model (Opus 5.5 is the default) and paste what your model generated into your answer (the block printed above). Compare the source, generated text, and editor rewrite. Describe one successful rewrite and one failure or ambiguous case. Would you use this system in production in any form? (There are no wrong answers on this last question! We're looking for your reasoning about what kinds of limitations and shortcomings might feel consequential enough that you would rather not use it, or if you think even an imperfect system for this task could still be helpful in some way.)
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # Paste the block of rewrites here, then: one successful rewrite and one failure or ambiguous case (by pair_id), and whether you'd use this in production.
    answer_7 = PLACEHOLDER
    mo.md(answer_7)
    return (answer_7,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    # Part II: Language model tasks in your project

    In Part I you worked through one problem in two forms, labeling a sentence and rewriting it, and compared trained and training-free ways of getting a model to do each. Now turn to your group's project.

    By a *task* we mean a specific, repeatable job with a clear input and output that a language model could do. Examples include labeling, extracting information, rewriting, summarizing, generating examples, and scoring or checking other outputs. A task might be part of what your project contributes, part of how you evaluate it, part of how you build or clean your data, or play some other role.
    """)
    return


@app.cell(hide_code=True)
def _():
    mo.accordion({"Example (a made-up project, to show the level of detail we're looking for)": mo.md(r"""
    A group is building a tool that helps a local news site find quotes attributed to unnamed sources.

    *Question 8 (one task):* label each sentence containing a quote as *named source*, *unnamed source*, or *no quote*. Input: "A senior official, speaking on condition of anonymity, said the plan was dead." Output: *unnamed source*. Role: this is the core of what the tool does. Volume: about 200 articles a day with ~5 quotes each, so ~1,000 sentences a day of ~40 words, ongoing.

    *Question 9:* start by prompting a small hosted model (Claude Haiku) with a few examples. At ~150 input tokens per sentence, 1,000 sentences a day is ~150,000 input tokens, about 2 cents a day, so prompting is the obvious first try. To check it, we'd label 50 sentences ourselves and compare. If it gets fewer than ~85% of unnamed-source sentences right, we'd add examples of the tricky cases, then consider training a small classifier on our Lab 3 annotations.

    *For Question 10, Option B, a table like this is enough:*

    | | estimate |
    |---|---|
    | model calls or training examples | |
    | input and output length (tokens) | |
    | hardware or API, and cost | |
    | time | |
    | bottleneck | |
    | biggest risk, and how to check it early | |
    """)})
    return


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 8: Identify tasks `[GROUP]`

    List one or two tasks that are relevant to your project. For each one, give an example input and the output you would want, and say what role the task plays in your project. Estimate how much of the task needs to be done: how many items, roughly how long each input is, and whether it happens once or keeps happening. You may draw on your Lab 3 annotation task, for example as a source of training examples or as a way to check outputs, but you don't have to.
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # For each task: example input and output, its role in the project, and how much of it needs doing.
    answer_8 = PLACEHOLDER
    mo.md(answer_8)
    return (answer_8,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 9: Choose an approach `[GROUP]`

    For each task from Question 8, reason through an approach that seems reasonable. Which model would you start with, and would you use prompting alone or train it? Given how much of the task you need to do, what would it cost, or what hardware would it need? What would you check first to see whether the approach works, and what result would make you change course?
    """)
    return


@app.cell
def _(PLACEHOLDER):
    # For each task: starting model, prompting or training, cost or hardware at your volume, first check, what would change your mind.
    answer_9 = PLACEHOLDER
    mo.md(answer_9)
    return (answer_9,)


@app.cell(hide_code=True)
def _():
    mo.md(r"""
    ### Question 10: One step further `[INDIVIDUAL]`

    Pick one task from Question 9 and do one of the following.

    **Option A: Proof of concept.** Try your approach on 10 to 20 of your own examples, using any model. Paste a few inputs and outputs. How well did it work? What surprised you, and what would you change before building on it?

    **Option B: Detailed plan.** Work out the resources your approach needs as precisely as you can: the number of model calls or training examples, input and output lengths, GPU type and hours or API cost, and the time it would take. What is the bottleneck, whether that's money, compute, data, labeling effort or something else? What is the biggest risk, and how would you find out early whether it's a problem?

    For Option A you can use the small tool below with any Claude model, or any other setup you like.
    """)
    return


@app.cell(hide_code=True)
def _():
    poc_prompt = mo.ui.text_area(value="Your instructions here.\n\nInput: {input}\nOutput:", rows=5, full_width=True,
                                 label="Prompt (keep {input} where each input goes)")
    poc_inputs = mo.ui.text_area(placeholder="One input per line", rows=8, full_width=True, label="Inputs")
    poc_model = mo.ui.dropdown({"Claude Haiku 5.5": "claude-haiku-5-5",
                                "Claude Opus 5.5": "claude-opus-5-5"}, value="Claude Haiku 5.5", label="Model")
    poc_button = mo.ui.run_button(label="Run on all inputs")
    mo.vstack([poc_prompt, poc_inputs, mo.hstack([poc_model, poc_button], justify="start")])
    return poc_button, poc_inputs, poc_model, poc_prompt


@app.cell(hide_code=True)
def _(RUNS_DIR, poc_button, poc_inputs, poc_model, poc_prompt):
    mo.stop(not poc_button.value)
    _inputs = [_x.strip() for _x in poc_inputs.value.splitlines() if _x.strip()]
    mo.stop(not _inputs or "{input}" not in poc_prompt.value,
            mo.md("_Add at least one input, and keep `{input}` in the prompt._"))
    _rows = []
    for _x in _inputs:
        try:
            _r = call_model(poc_prompt.value.replace("{input}", _x), {"effort": "low", "max_output_tokens": 1024},
                            "llm", poc_model.value)
            _rows.append({"input": _x, "output": _r["raw_output"], "input_tokens": _r["input_tokens"],
                          "output_tokens": _r["output_tokens"]})
        except Exception as _e:
            _rows.append({"input": _x, "output": None, "error": f"{type(_e).__name__}: {_e}"})
    _df = pd.DataFrame(_rows)
    (RUNS_DIR / "project").mkdir(parents=True, exist_ok=True)
    _path = RUNS_DIR / "project" / f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{poc_model.value}.csv"
    _df.to_csv(_path, index=False)
    mo.vstack([mo.md(f"Saved `{_path}`. Estimated cost: ${claude_cost(poc_model.value, _df.get('input_tokens', []), _df.get('output_tokens', []))}"),
               mo.ui.table(_df, selection=None)])
    return


@app.cell
def _(PLACEHOLDER):
    # Say which option you chose. A: inputs and outputs, how well it worked, what you'd change. B: resources, bottleneck, biggest risk and how to check it early.
    answer_10 = PLACEHOLDER
    mo.md(answer_10)
    return (answer_10,)


if __name__ == "__main__":
    app.run()
