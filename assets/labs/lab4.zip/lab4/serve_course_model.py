"""How the Lab 4 course model is served (for reading; the course staff run this, you don't need to).

The course model runs on Modal (https://modal.com), a service that rents GPUs by the second and starts them when
a request arrives. This file is everything Modal needs: what to install, which GPU to use, and how to start the
model server. It is a lightly trimmed copy of the script we actually deploy.

What is being served
    One copy of Qwen3-8B on one NVIDIA L40S GPU, under two names:
      - "qwen3-8b":      Qwen3-8B as released
      - "qwen3-8b-wnc":  Qwen3-8B plus the LoRA adapter we trained on the WNC training split
    Both names use the same 8B weights in GPU memory. The adapter is a small set of extra weights (rank 16,
    about 15 million parameters, ~60 MB) that vLLM applies on top of the base model only for requests that ask for "qwen3-8b-wnc". That is why serving both costs about the same as serving one.

How requests reach it
    vLLM (https://docs.vllm.ai) runs an OpenAI-compatible server inside the container, so the notebook sends an
    ordinary chat-completions request with model="qwen3-8b-wnc" or "qwen3-8b". (It also switches off Qwen3's "thinking"
    mode, which the adapter was trained without.) vLLM batches requests that arrive together
    and runs them through the GPU at once. That batching is why one GPU can classify well over a hundred
    sentences per second when many requests are in flight, even though each single request takes about half a
    second end to end.

Why it sometimes takes ~2 minutes to answer
    To save money the server shuts down after 10 minutes without requests. The next request starts a fresh
    container: Modal attaches a GPU, vLLM loads the 16 GB of weights onto it and warms up. That cold start takes
    about 2-2.5 minutes. The notebook's "Wake / check" button sends one tiny request to start this early.

Deploying it yourself (optional; needs your own Modal account; the base model and adapter are both public)
    modal deploy serve_course_model.py
"""
import os
import subprocess
import time

import modal

MODEL = "Qwen/Qwen3-8B"                              # base model, downloaded from Hugging Face
MODEL_REV = "b968826d9c46dd6066d109eabc6255188de91218"  # pinned version, so the model can't change under us
ADAPTER_REPO = "claran/lab4-wnc-qwen3-8b-lora"        # the trained LoRA adapter (public: huggingface.co/claran/lab4-wnc-qwen3-8b-lora)
ADAPTER_REV = "1fe4b96da54859264a0160d3c2b82056ac99804d"
MAX_LEN = 4096                                       # longest prompt + answer, in tokens, the server accepts

# The software environment: a small Linux image with vLLM installed.
image = (
    modal.Image.debian_slim(python_version="3.12")
    .uv_pip_install("vllm==0.31.0", "huggingface_hub[hf_xet]")
    .env({"HF_HUB_CACHE": "/root/.cache/huggingface", "VLLM_USE_FLASHINFER_SAMPLER": "0"})
)
# Persistent storage, so the 16 GB of weights are downloaded once rather than at every start.
hf_cache = modal.Volume.from_name("lab4-hf-cache", create_if_missing=True)
VOLUMES = {"/root/.cache/huggingface": hf_cache}

app = modal.App("lab4-vllm-l40s")


@app.function(image=image, volumes=VOLUMES, timeout=3600)
def download():
    """Run once: copy the base model and the adapter into the persistent volume."""
    from huggingface_hub import snapshot_download
    snapshot_download(MODEL, revision=MODEL_REV, ignore_patterns=["*.pt", "*.bin"])
    snapshot_download(ADAPTER_REPO, revision=ADAPTER_REV)
    hf_cache.commit()


@app.server(
    image=image,
    gpu="L40S",                    # 48 GB GPU; the 8B model in 16-bit takes about 16 GB, the rest is for the KV cache
    volumes=VOLUMES,
    secrets=[modal.Secret.from_name("lab4-vllm-keys")],  # the course key(s), kept outside this file
    port=8000,
    unauthenticated=True,          # Modal lets requests through; vLLM itself checks the course key
    startup_timeout=20 * 60,
    scaledown_window=10 * 60,      # shut down after 10 minutes with no requests
    max_containers=1,              # never more than one GPU, which caps the cost
    target_concurrency=64,
)
class Server:
    @modal.enter()
    def start(self):
        """Start vLLM when the container starts, and wait until it answers health checks."""
        from huggingface_hub import snapshot_download
        adapter = snapshot_download(ADAPTER_REPO, revision=ADAPTER_REV, local_files_only=True)
        cmd = [
            "vllm", "serve", MODEL, "--revision", MODEL_REV,
            "--served-model-name", "qwen3-8b",          # requests with model="qwen3-8b" get the plain model
            "--enable-lora", "--max-lora-rank", "16",
            "--lora-modules", f"qwen3-8b-wnc={adapter}",  # requests with model="qwen3-8b-wnc" get the model + adapter
            "--max-model-len", str(MAX_LEN),
            "--host", "0.0.0.0", "--port", "8000",
            "--api-key", *os.environ["VLLM_API_KEYS"].split(),
        ]
        self.proc = subprocess.Popen(cmd, env={**os.environ, "HF_HUB_OFFLINE": "1"})
        import urllib.request
        while True:
            if self.proc.poll() is not None:
                raise RuntimeError(f"vllm exited with {self.proc.returncode}")
            try:
                urllib.request.urlopen("http://localhost:8000/health", timeout=2)
                return
            except Exception:
                time.sleep(2)

    @modal.exit()
    def stop(self):
        self.proc.terminate()
