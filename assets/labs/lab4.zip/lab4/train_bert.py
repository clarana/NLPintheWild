"""Train bert-mini for Question 6 from a terminal, so the notebook stays free while it runs.

    python train_bert.py --seeds 0 1 2                     # the default setting, three seeds
    python train_bert.py --batch-size 32 --seeds 0 1 2     # change any setting
    python train_bert.py --pairs 8000 --epochs 2 --seeds 0 # 8,000 pairs for two epochs

Uses exactly the same training code as the notebook (it is imported from the Lab 4 notebook file) and saves
to the same places: results in lab4_runs/bert/<setting>_seed<k>/ and weights in lab4_ckpts/. The notebook's
Question 6 tools pick these runs up automatically. A run that already exists is skipped, so it is safe to
rerun the same command.
"""
import argparse
import importlib.util
import math
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUDGET = 32_000  # training sentences per run (pairs x 2 x epochs), same as the notebook


def load_notebook(path: Path):
    """Import the Lab 4 notebook as a module to reuse its training functions."""
    spec = importlib.util.spec_from_file_location("lab4_notebook", path)
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent))
    spec.loader.exec_module(module)
    return module


def find_notebook() -> Path:
    if (HERE / "lab4.py").exists():
        return HERE / "lab4.py"
    sys.exit("Couldn't find lab4.py next to this script; pass --notebook PATH.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pairs", type=int, default=16_000, help="training pairs (default 16000)")
    ap.add_argument("--epochs", type=int, default=1, help="epochs (default 1)")
    ap.add_argument("--batch-size", type=int, default=256, help="batch size (default 256)")
    ap.add_argument("--lr", type=float, default=1e-4, help="learning rate (default 0.0001)")
    ap.add_argument("--drop-conflicts", action="store_true", help="leave out label-conflict pairs")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0], help="one or more seeds (default 0)")
    ap.add_argument("--notebook", type=Path, default=None, help="path to the Lab 4 notebook (found automatically)")
    ap.add_argument("--out-dir", type=Path, default=HERE, help="folder that holds lab4_runs/ and lab4_ckpts/")
    args = ap.parse_args()

    used = 2 * args.pairs * args.epochs
    if used > BUDGET:
        sys.exit(f"This setting uses {used:,} training sentences per run; the budget is {BUDGET:,} (pairs x 2 x epochs).")

    nb = load_notebook(args.notebook or find_notebook())
    import pandas as pd

    data = HERE / "data" / "wnc"
    pairs = pd.read_csv(data / "pairs.csv.gz", keep_default_na=False)
    sentences = pd.read_csv(data / "sentences.csv.gz", keep_default_na=False)
    train = pairs[pairs["split"] == "train"].reset_index(drop=True)
    test = sentences[sentences["split"] == "test"].reset_index(drop=True)

    for seed in args.seeds:
        cfg = {"n_train_pairs": args.pairs, "epochs": args.epochs, "batch_size": args.batch_size, "lr": args.lr,
               "drop_conflicts": args.drop_conflicts, "seed": seed}
        label = nb.bert_run_label(cfg)
        out_dir = args.out_dir / "lab4_runs" / "bert" / label
        if (out_dir / "metrics.json").exists():
            print(f"{label}: already done, skipping")
            continue
        steps = args.epochs * math.ceil(2 * args.pairs / args.batch_size)
        done = {"n": 0}
        t0 = time.time()

        def tick():
            done["n"] += 1
            if done["n"] % max(1, steps // 10) == 0 or done["n"] == steps:
                print(f"  {label}: step {done['n']}/{steps} ({time.time() - t0:.0f} s)", flush=True)

        print(f"{label}: training ({steps} steps)", flush=True)
        m = nb.train_bert_mini(cfg, train, test, out_dir, progress=tick,
                               ckpt_dir=args.out_dir / "lab4_ckpts" / label)
        print(f"{label}: test accuracy {m['accuracy']:.4f} "
              f"[{m['acc_95ci'][0]:.3f}, {m['acc_95ci'][1]:.3f}], {m['train_s']:.0f} s on {m['device']}", flush=True)


if __name__ == "__main__":
    main()
