"""Build the Lab 4 release of the Wiki Neutrality Corpus (WNC) from the authors' archive.

Usage (from the repo root):

    python lab4/data/wnc/prepare_wnc.py                     # downloads the archive if needed
    python lab4/data/wnc/prepare_wnc.py --archive bias_data.zip

Standard library only. Running it twice produces byte-identical files, and
manifest.json records the hash of each one.

What it does, in order (see README.md for the reasoning):

1. Read the three word-level edit files (biased.word.train / .dev / .test).
   Each line is one Wikipedia edit: a sentence before an NPOV edit and the
   same sentence after it.
2. Keep only the human-readable before/after text (`src_raw`, `tgt_raw`) and
   the revision id. The text is copied exactly; nothing is lowercased,
   re-tokenized, or otherwise cleaned.
3. Leakage control. The official test split is kept whole. A dev pair is
   dropped if either of its sentences also appears in test. A train pair is
   dropped if either of its sentences also appears in test or in the kept dev
   pairs (dev is the demonstration pool for in-context learning).
   excluded_pairs.csv lists every dropped pair and the reason.
4. Classification view: each pair becomes two sentences, labeled `biased`
   (before the edit) and `neutral` (after the edit). A sentence that appears
   before one edit and after another edit in the same split gets both labels;
   we flag it (`label_conflict`) instead of silently picking one.
5. Fixed evaluation subset: a seeded random sample of test pairs without label
   conflicts. Both sentences of a sampled pair are included.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import random
import sys
import urllib.request
import zipfile
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent

SOURCE_URL = "https://www.dropbox.com/s/qol3rmn0rq0dfhn/bias_data.zip?dl=1"
SOURCE_SHA256 = "caba18ddad6d24e56610091ba1d0203cb0b069b59d7a07ab30c8a78412645294"
SPLITS = ("train", "dev", "test")
EXPECTED_ROWS = {"train": 53_803, "dev": 700, "test": 1_000}
ORIGINAL_COLUMNS = ["id", "src_tok", "tgt_tok", "src_raw", "tgt_raw", "src_POS_tags", "tgt_parse_tags"]

EVAL_SEED = 11811
EVAL_PAIRS = 200  # 200 pairs = 400 sentences

PAIR_FIELDS = ["pair_id", "split", "source_file", "source_line", "rev_id",
               "biased_text", "neutral_text", "label_conflict", "in_eval_subset"]
SENTENCE_FIELDS = ["sentence_id", "pair_id", "split", "text", "label",
                   "label_conflict", "in_eval_subset"]
EXCLUDED_FIELDS = ["pair_id", "split", "source_file", "source_line", "rev_id",
                   "reason", "biased_text", "neutral_text"]


# ---------------------------------------------------------------- reading

def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fetch_archive(path: Path) -> None:
    print(f"downloading {SOURCE_URL}\n  -> {path}", file=sys.stderr)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".part")
    with urllib.request.urlopen(SOURCE_URL, timeout=300) as r, open(tmp, "wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)
    tmp.rename(path)


def read_split(z: zipfile.ZipFile, split: str) -> list[dict]:
    name = f"bias_data/WNC/biased.word.{split}"
    text = z.read(name).decode("utf-8")  # strict: fail loudly on bad bytes
    pairs = []
    for line_no, line in enumerate(text.split("\n"), start=1):
        if line == "":
            continue
        fields = line.split("\t")
        if len(fields) != len(ORIGINAL_COLUMNS):
            raise ValueError(f"{name}:{line_no}: expected 7 tab-separated fields, got {len(fields)}")
        row = dict(zip(ORIGINAL_COLUMNS, fields))
        if not row["src_raw"] or not row["tgt_raw"]:
            raise ValueError(f"{name}:{line_no}: empty sentence")
        if row["src_raw"] == row["tgt_raw"]:
            raise ValueError(f"{name}:{line_no}: before and after text are identical")
        pairs.append({
            "pair_id": f"{split}-{line_no:05d}",
            "split": split,
            "source_file": f"biased.word.{split}",
            "source_line": line_no,
            "rev_id": row["id"],
            "biased_text": row["src_raw"],
            "neutral_text": row["tgt_raw"],
        })
    if len(pairs) != EXPECTED_ROWS[split]:
        raise ValueError(f"{name}: expected {EXPECTED_ROWS[split]} rows, got {len(pairs)}")
    return pairs


# ---------------------------------------------------------------- transforming

def texts_of(pairs: list[dict]) -> set[str]:
    return {t for p in pairs for t in (p["biased_text"], p["neutral_text"])}


def drop_overlap(pairs: list[dict], protected: dict[str, set[str]]) -> tuple[list[dict], list[dict]]:
    """Drop pairs where either sentence occurs in a protected split. Returns (kept, excluded)."""
    kept, excluded = [], []
    for p in pairs:
        hits = [name for name, texts in protected.items()
                if p["biased_text"] in texts or p["neutral_text"] in texts]
        if hits:
            excluded.append({**p, "reason": "shares an exact sentence with " + " and ".join(hits)})
        else:
            kept.append(p)
    return kept, excluded


def mark_label_conflicts(pairs: list[dict]) -> int:
    """Flag pairs whose sentences appear as both `biased` and `neutral` within the split."""
    as_biased = {p["biased_text"] for p in pairs}
    as_neutral = {p["neutral_text"] for p in pairs}
    conflicted = as_biased & as_neutral
    for p in pairs:
        p["label_conflict"] = p["biased_text"] in conflicted or p["neutral_text"] in conflicted
    return len(conflicted)


def choose_eval_subset(test: list[dict]) -> None:
    candidates = sorted(p["pair_id"] for p in test if not p["label_conflict"])
    chosen = set(random.Random(EVAL_SEED).sample(candidates, EVAL_PAIRS))
    for p in test:
        p["in_eval_subset"] = p["pair_id"] in chosen


def to_sentences(pairs: list[dict]) -> list[dict]:
    rows = []
    for p in pairs:
        for suffix, text_key, label in (("b", "biased_text", "biased"), ("n", "neutral_text", "neutral")):
            rows.append({
                "sentence_id": f"{p['pair_id']}-{suffix}",
                "pair_id": p["pair_id"],
                "split": p["split"],
                "text": p[text_key],
                "label": label,
                "label_conflict": p["label_conflict"],
                "in_eval_subset": p["in_eval_subset"],
            })
    return rows


# ---------------------------------------------------------------- writing

def csv_bytes(rows: list[dict], fields: list[str]) -> bytes:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
    w.writeheader()
    for r in rows:
        w.writerow({k: (str(v).lower() if isinstance(v, bool) else v) for k, v in r.items()})
    return buf.getvalue().encode("utf-8")


def write_file(path: Path, data: bytes) -> str:
    if path.suffix == ".gz":  # mtime=0 and no filename keep the gzip bytes reproducible
        buf = io.BytesIO()
        with gzip.GzipFile(filename="", mode="wb", fileobj=buf, mtime=0, compresslevel=9) as g:
            g.write(data)
        data = buf.getvalue()
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------- main

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--archive", type=Path, default=HERE / "source" / "bias_data.zip",
                    help="path to the authors' bias_data.zip (downloaded here if missing)")
    ap.add_argument("--out", type=Path, default=HERE, help="output directory")
    args = ap.parse_args()

    if not args.archive.exists():
        fetch_archive(args.archive)
    digest = sha256_of(args.archive)
    if digest != SOURCE_SHA256:
        sys.exit(f"archive sha256 {digest} does not match the expected {SOURCE_SHA256}; "
                 "the upstream file changed, so check it before rebuilding")

    with zipfile.ZipFile(args.archive) as z:
        raw = {s: read_split(z, s) for s in SPLITS}

    test = raw["test"]
    dev, excluded_dev = drop_overlap(raw["dev"], {"test": texts_of(test)})
    train, excluded_train = drop_overlap(raw["train"], {"test": texts_of(test), "dev": texts_of(dev)})
    kept = {"train": train, "dev": dev, "test": test}

    conflict_texts = {s: mark_label_conflicts(kept[s]) for s in SPLITS}
    for s in ("train", "dev"):
        for p in kept[s]:
            p["in_eval_subset"] = False
    choose_eval_subset(test)

    # Invariants the release promises; fail rather than write a bad release.
    assert not texts_of(train) & (texts_of(dev) | texts_of(test)), "train overlaps dev/test"
    assert not texts_of(dev) & texts_of(test), "dev overlaps test"
    for s in SPLITS:
        assert len({p["pair_id"] for p in kept[s]}) == len(kept[s])

    pairs = train + dev + test
    sentences = to_sentences(pairs)
    eval_rows = [r for r in sentences if r["in_eval_subset"]]
    excluded = excluded_dev + excluded_train

    args.out.mkdir(parents=True, exist_ok=True)
    outputs = {
        "pairs.csv.gz": write_file(args.out / "pairs.csv.gz", csv_bytes(pairs, PAIR_FIELDS)),
        "sentences.csv.gz": write_file(args.out / "sentences.csv.gz", csv_bytes(sentences, SENTENCE_FIELDS)),
        "eval_subset.csv": write_file(args.out / "eval_subset.csv", csv_bytes(eval_rows, SENTENCE_FIELDS)),
        "excluded_pairs.csv": write_file(args.out / "excluded_pairs.csv", csv_bytes(excluded, EXCLUDED_FIELDS)),
    }

    manifest = {
        "dataset": "Wiki Neutrality Corpus (Pryzant et al., AAAI 2020), word-level edits, Lab 4 release",
        "source": {"url": SOURCE_URL, "sha256": SOURCE_SHA256,
                   "files": [f"bias_data/WNC/biased.word.{s}" for s in SPLITS]},
        "settings": {"eval_seed": EVAL_SEED, "eval_pairs": EVAL_PAIRS,
                     "overlap_rule": "exact string match on either sentence; test kept whole; "
                                     "dev drops pairs overlapping test; train drops pairs overlapping test or kept dev"},
        "counts": {
            s: {"original_pairs": len(raw[s]),
                "excluded_pairs": len(raw[s]) - len(kept[s]),
                "released_pairs": len(kept[s]),
                "released_sentences": 2 * len(kept[s]),
                "texts_with_both_labels": conflict_texts[s],
                "pairs_flagged_label_conflict": sum(p["label_conflict"] for p in kept[s])}
            for s in SPLITS
        },
        "eval_subset": {"pairs": EVAL_PAIRS, "sentences": len(eval_rows)},
        "outputs_sha256": outputs,
        "script_sha256": sha256_of(Path(__file__)),
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest["counts"], indent=2))
    print(f"wrote {', '.join(outputs)} and manifest.json to {args.out}")


if __name__ == "__main__":
    main()
