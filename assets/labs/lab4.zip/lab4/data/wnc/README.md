# WNC for Lab 4: biased vs. neutral sentences

This folder holds the version of the **Wiki Neutrality Corpus (WNC)** used in Lab 4,
and the script that builds it from the authors' original archive.

> Pryzant, R., Diehl Martinez, R., Dass, N., Kurohashi, S., Jurafsky, D., & Yang, D. (2020).
> *Automatically Neutralizing Subjective Bias in Text.* AAAI 2020.
> [paper](https://arxiv.org/abs/1911.09709) · [code and data](https://github.com/rpryzant/neutralizing-bias)

You can use the prepared files directly. Or rebuild them yourself and confirm you get the same bytes:

```bash
python prepare_wnc.py
```

The script needs only Python 3.9+ (no packages). It downloads the authors' archive (~105 MB) into
`source/` and checks the file's SHA-256 hash. It then rewrites the files below, and `manifest.json`
lists their hashes. Already have the zip? Pass `--archive path/to/bias_data.zip`. To write
somewhere else, pass `--out some/dir`.

```python
import pandas as pd
sentences = pd.read_csv("sentences.csv.gz", keep_default_na=False)   # classification
pairs     = pd.read_csv("pairs.csv.gz", keep_default_na=False)       # rewriting
eval_set  = pd.read_csv("eval_subset.csv", keep_default_na=False)    # fixed evaluation set
```

(`keep_default_na=False` keeps pandas from reading a sentence such as "NA" as missing.)

---

## 1. What the original data looks like

WNC was harvested from Wikipedia revisions. In each one, an editor changed a sentence to follow
Wikipedia's [Neutral Point of View](https://en.wikipedia.org/wiki/Wikipedia:Neutral_point_of_view)
(NPOV) policy. One example is one edit: **the sentence before** and **the sentence after**.

We use the *word-level* files, where the edit changed a single word or phrase:
`biased.word.train` (53,803 edits), `biased.word.dev` (700), and `biased.word.test` (1,000).
Each line is one edit, with seven tab-separated columns and no header row:

| column | meaning | kept? |
|---|---|---|
| `id` | Wikipedia diff id (`https://en.wikipedia.org/w/index.php?diff=<id>`). Not unique: one revision can contain several edits. | yes, as `rev_id` |
| `src_tok`, `tgt_tok` | before/after sentence, split into BERT WordPiece tokens (`stand ##off`) | no |
| `src_raw`, `tgt_raw` | before/after sentence as readable text | yes |
| `src_POS_tags`, `tgt_parse_tags` | part-of-speech and dependency tags the authors' models used | no |

"Raw" doesn't mean untouched Wikipedia text. The authors had already lowercased the sentences and
stripped wiki markup. We copy `src_raw`/`tgt_raw` exactly, with no further cleaning.

The archive has other files too. `biased.full` has all 181k edits, and every dev and test edit
is in it, so **don't** add it to training. `neutral` has unedited neighboring sentences, which are
shorter on average (a length shortcut). There are also out-of-domain samples. We don't use any of them.

## 2. What we changed, step by step

1. **Keep the original splits.** We never re-shuffle sentences across splits. Both sentences of an
   edit always stay together (an edit is the unit of splitting).
2. **Remove leakage.** Sometimes the exact same sentence appears in two splits, e.g. one sentence
   edited twice in different revisions. A model could then memorize a test sentence during training.
   - test: kept whole (1,000 pairs), so results stay comparable with the paper.
   - dev: drop pairs where either sentence also appears in test (2 dropped).
   - train: drop pairs where either sentence also appears in test or dev (31 dropped).

   Dev is meant as the **pool for in-context demonstrations**, so it's kept separate from training.
   Each dropped pair is listed in `excluded_pairs.csv` with the reason.
3. **Make the classification view.** Each edit becomes two labeled sentences: the sentence before
   the edit is `biased`, and the sentence after is `neutral`. The classes are balanced 50/50 by construction.
4. **Flag, don't fix, contradictory labels.** Some sentences were edited *away from* in one pair
   and edited *toward* in another, so step 3 gives them both labels (573 such sentences in train,
   affecting 776 pairs; 1 sentence in test, affecting 2 pairs). We keep them, with
   `label_conflict = true`, so you can decide whether to filter them.
5. **Fix one evaluation subset.** 200 test pairs (400 sentences, 200 per label) are drawn with a
   fixed seed (11811) from test pairs without label conflicts. Use the same subset in every
   experiment so the numbers are comparable.

### Worked example

Original line 2 of `biased.word.test` (tokenized and tag columns omitted):

```
235640083 \t ... \t the 51 day standoff and ensuing murder of 76 men, women, and children--the branch davidians--in waco, texas.
          \t the 51 day standoff and ensuing deaths of 76 men, women, and children--the branch davidians--in waco, texas. \t ...
```

becomes one row of `pairs.csv.gz` (`pair_id = test-00002`, `biased_text` = "...ensuing murder of...",
`neutral_text` = "...ensuing deaths of...") and two rows of `sentences.csv.gz`:

| sentence_id | pair_id | text | label |
|---|---|---|---|
| `test-00002-b` | `test-00002` | the 51 day standoff and ensuing **murder** of 76 men, ... | biased |
| `test-00002-n` | `test-00002` | the 51 day standoff and ensuing **deaths** of 76 men, ... | neutral |

## 3. Files

| file | rows | one row is | use it for |
|---|---|---|---|
| `pairs.csv.gz` | 55,470 | one edit (before → after) | rewriting/neutralizing; grouping sentences by pair |
| `sentences.csv.gz` | 110,940 | one sentence with a label | biased/neutral classification |
| `eval_subset.csv` | 400 | one sentence (subset of `sentences`) | the fixed evaluation set |
| `excluded_pairs.csv` | 33 | one dropped edit + reason | auditing step 2 |
| `manifest.json` | – | source URL and hash, settings, counts, output hashes | checking a rebuild |
| `prepare_wnc.py` | – | the transformation itself | rebuilding / reading exactly what was done |

**`pairs.csv.gz`**: `pair_id` (`<split>-<line>`, the line number in the original file), `split`
(`train` / `dev` / `test`), `source_file`, `source_line`, `rev_id`, `biased_text` (before the edit),
`neutral_text` (after the edit; the editor's rewrite), `label_conflict`, `in_eval_subset`.

**`sentences.csv.gz`** and **`eval_subset.csv`**: `sentence_id` (`<pair_id>-b` or `<pair_id>-n`), `pair_id`,
`split`, `text`, `label` (`biased` / `neutral`), `label_conflict`, `in_eval_subset`.

| split | pairs | sentences | role |
|---|---|---|---|
| train | 53,772 | 107,544 | training |
| dev | 698 | 1,396 | in-context demonstrations / tuning |
| test | 1,000 | 2,000 | evaluation (use `eval_subset.csv` unless told otherwise) |

## 4. What the labels do and don't mean

- `biased` / `neutral` mean "before / after an NPOV edit." They are **not** independent judgments
  that a sentence is biased. A Wikipedia editor made one edit, and other editors might disagree.
  Some edits even look backwards. In `test-00001`, "because their rights had been violated" was
  changed to "under the pretext that their rights had been violated."
- The two sentences of a pair usually differ by a word or two. A classifier that sees only one
  sentence has to find the subjective wording without the comparison. Inside a pair, the
  `neutral` sentence is one acceptable rewrite, not the only one.
- In the original, a pair's `biased` and `neutral` sentences always differ (the script checks
  this). Some pairs share a `biased` sentence with other pairs, because one sentence received
  different edits in different revisions.

## 5. Source, license, and versions

- Archive: `bias_data.zip` (Dropbox mirror listed in `prepare_wnc.py`; the original Stanford
  link `http://bit.ly/bias-corpus` did not respond on 2026-10-30). SHA-256
  `caba18ddad6d24e56610091ba1d0203cb0b069b59d7a07ab30c8a78412645294`.
- The authors' code repository is MIT-licensed. The data archive has no separate license file.
  The sentences come from Wikipedia, whose text is licensed CC BY-SA. Cite the paper above if
  you use the data.
- Earlier course experiments (design notes, Oct 2026) used a looser filter. It dropped only train
  pairs whose *before* sentence appeared as a test *before* sentence (53,798 train pairs). This
  release drops overlap on either sentence and against dev too (53,772 train pairs). Results
  from those runs are close to, but not exactly, results on this release.
