# Lab 4: Model Adaptation and Inference

Due **Friday, November 20, 11:59 pm** on Canvas. The notebook `lab4.py` has the full instructions.

## Setup

1. **Python environment.** Use the course environment from earlier labs (it already has marimo, PyTorch and
   transformers). Add the Anthropic client:

   ```
   uv add anthropic        # or: pip install anthropic
   ```

2. **Keys.** Copy `.env.example` to `.env` in this folder and fill in the course key (posted on Piazza) and
   your Anthropic API key (ask on Piazza if you need one). Never paste a key into the notebook.

3. **Start the bert-mini training first.** Question 6 needs several training runs: about 30 minutes in total
   on a laptop CPU, or a few minutes on a recent Mac or with a CUDA GPU. In a terminal in this folder:

   ```
   python train_bert.py --seeds 0 1 2
   ```

   It keeps running while you work on the notebook.

4. **Open the notebook:**

   ```
   marimo edit lab4.py
   ```

## What's in this folder

| | |
|---|---|
| `lab4.py` | the lab notebook |
| `data/wnc/` | the prepared Wiki Neutrality Corpus (see its README for how it was built) |
| `data/tuned_curve.csv` | learning curve of the course model, plotted in the notebook |
| `train_bert.py` | trains bert-mini for Question 6 from a terminal |
| `serve_course_model.py` | how the course model is served (for reading; you don't need to run it) |
| `.env.example` | template for your keys |

## What to submit

This notebook with your answers, and a zip of the `lab4_runs` folder the notebook creates. Don't submit
`lab4_ckpts` (trained weights) or your `.env`.
